/** @type {import('tailwindcss').Config} */
// Tailwind CSS v3 配置：注入项目主题色板（中国红主色 + 告警辅助色）
export default {
  content: ['./index.html', './src/**/*.{vue,js}'],
  theme: {
    extend: {
      colors: {
        // 主色调：中国红
        'china-red': '#C41E3A',
        // 辅助色：警戒黄 / 危险橙 / 核心告警红
        'alarm-yellow': '#F59E0B',
        'alarm-orange': '#EA580C',
        'alarm-red': '#DC2626',
      },
      boxShadow: {
        // 红色庄重卡片阴影
        shrine: '0 4px 16px rgba(196, 30, 58, 0.12)',
      },
    },
  },
  plugins: [],
}
