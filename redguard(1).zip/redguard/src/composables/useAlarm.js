import { ref } from 'vue'

/**
 * useAlarm —— 分级告警引擎（阶段4 增强版）
 * 告警分级：none 无 / warn 一级警戒(语音劝阻) / danger 二级危险(声光闪烁) / core 三级严重(强声光+写日志)
 * 能力：
 *   1) 浏览器语音合成播报（speechSynthesis）
 *   2) Web Audio 警报音（danger 中速 / core 急促）
 *   3) 告警日志记录（含 Canvas 快照 dataURL）
 *   4) 日志 localStorage 持久化（刷新页面保留）
 *   5) 日志文本导出下载（.txt）
 */

// 日志本地持久化键名
const LOG_STORAGE_KEY = 'redguard_alarm_logs_v1'
// 容量控制：最多保留 50 条日志；其中最多 12 条携带快照（dataURL 体积大，防止撑爆 localStorage 5MB）
const MAX_LOGS = 50
const MAX_SNAPSHOTS = 12

export function useAlarm() {
  const alarmLevel = ref('none') // 当前告警等级
  const logs = ref(loadLogs()) // 告警日志（新事件置顶，初始化即从 localStorage 恢复）

  let audioCtx = null // Web Audio 上下文（懒创建，需用户手势后可用）
  let beepTimer = null // 警报音节奏定时器
  let osc = null // 当前发声振荡器

  /* ---------- 浏览器语音合成播报 ---------- */
  /**
   * 播报中文语音（红色文化温馨劝阻/警告话术）
   * @param {string} text 播报文本
   */
  function speak(text) {
    try {
      if (!('speechSynthesis' in window)) return
      const u = new SpeechSynthesisUtterance(text)
      u.lang = 'zh-CN'
      u.rate = 1
      // 优先选择中文音色
      const zhVoice = window.speechSynthesis.getVoices().find((v) => v.lang.startsWith('zh'))
      if (zhVoice) u.voice = zhVoice
      window.speechSynthesis.cancel() // 打断上一条，避免排队延迟
      window.speechSynthesis.speak(u)
    } catch {
      /* 语音播报失败不影响主流程 */
    }
  }

  /* ---------- Web Audio 警报音 ---------- */

  function ensureAudioCtx() {
    if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)()
    if (audioCtx.state === 'suspended') audioCtx.resume()
  }

  /**
   * 启动循环警报音
   * danger：中速间歇音（660Hz 方波）；core：急促双频音（880Hz）
   */
  function startAlarmSound(level) {
    stopAlarmSound()
    try {
      ensureAudioCtx()
      const core = level === 'core'
      const onMs = core ? 160 : 420 // 发声时长
      const offMs = core ? 90 : 380 // 静音时长
      let sounding = false
      const tick = () => {
        sounding = !sounding
        if (sounding) {
          osc = audioCtx.createOscillator()
          const gain = audioCtx.createGain()
          osc.type = 'square'
          osc.frequency.value = core ? 880 : 660
          gain.gain.setValueAtTime(0.07, audioCtx.currentTime) // 音量克制，避免刺耳
          osc.connect(gain).connect(audioCtx.destination)
          osc.start()
          beepTimer = setTimeout(tick, onMs)
        } else {
          if (osc) {
            osc.stop()
            osc = null
          }
          beepTimer = setTimeout(tick, offMs)
        }
      }
      tick()
    } catch {
      /* 音频不可用（如未交互）时静默降级 */
    }
  }

  /** 停止警报音 */
  function stopAlarmSound() {
    if (beepTimer) {
      clearTimeout(beepTimer)
      beepTimer = null
    }
    if (osc) {
      try {
        osc.stop()
      } catch {
        /* 忽略已停止的振荡器 */
      }
      osc = null
    }
  }

  /** 更新告警等级：升降级时切换警报音，恢复 none 时停止 */
  function setLevel(level) {
    if (alarmLevel.value === level) return
    alarmLevel.value = level
    if (level === 'none') stopAlarmSound()
    else startAlarmSound(level)
  }

  /* ---------- 告警日志（含快照 + 持久化） ---------- */
  /**
   * 写入一条告警日志（新事件置顶）
   * @param {'info'|'danger'|'critical'} level 日志等级
   * @param {string} type 告警类型（越界闯入/人员脱队/人数缺失/夜间入侵…）
   * @param {string} message 告警描述
   * @param {string|null} snapshot Canvas+视频合成快照（JPEG dataURL，可选）
   * @param {object} extra 附加字段（如夜间标识 night:true）
   */
  function addLog(level, type, message, snapshot = null, extra = {}) {
    const now = new Date()
    logs.value.unshift({
      id: now.getTime() + Math.random(),
      time: now.toLocaleTimeString('zh-CN', { hour12: false }),
      fullTime: now.toLocaleString('zh-CN', { hour12: false }),
      level,
      type,
      message,
      snapshot, // 告警瞬间画面快照（无摄像头时为 null）
      ...extra,
    })
    if (logs.value.length > MAX_LOGS) logs.value.length = MAX_LOGS
    persistLogs()
  }

  /** 清空日志（同时清除本地存储） */
  function clearLogs() {
    logs.value = []
    localStorage.removeItem(LOG_STORAGE_KEY)
  }

  /**
   * 将日志持久化到 localStorage
   * 容量策略：仅最近 MAX_SNAPSHOTS 条保留快照 dataURL，更早日志快照丢弃（文字记录保留）
   */
  function persistLogs() {
    try {
      let snapshotKept = 0
      const data = logs.value.map((log) => {
        const item = { ...log }
        if (item.snapshot) {
          if (snapshotKept < MAX_SNAPSHOTS) snapshotKept++
          else item.snapshot = null // 超出快照配额，仅保留文字
        }
        return item
      })
      localStorage.setItem(LOG_STORAGE_KEY, JSON.stringify(data))
    } catch {
      /* localStorage 配额超限时静默失败（不影响实时监测主流程） */
    }
  }

  /** 启动时从 localStorage 恢复日志（损坏数据安全回退为空列表） */
  function loadLogs() {
    try {
      const data = JSON.parse(localStorage.getItem(LOG_STORAGE_KEY))
      return Array.isArray(data) ? data : []
    } catch {
      return []
    }
  }

  /* ---------- 日志文本导出（.txt 下载） ---------- */
  /**
   * 导出全部告警日志为文本文件
   * 格式对齐业务字段：告警时间 / 告警等级 / 告警类型 / 告警内容 / 时段标识
   */
  function exportLogs() {
    if (!logs.value.length) return
    const levelName = { info: '劝阻提示', danger: '危险告警', critical: '严重告警' }
    const lines = [
      '============================================================',
      '           薪守疆隅——红色遗址智能电子围栏预警系统',
      '                     告 警 日 志 导 出',
      '============================================================',
      `导出时间：${new Date().toLocaleString('zh-CN', { hour12: false })}`,
      `日志条数：${logs.value.length} 条（新事件在前）`,
      '------------------------------------------------------------',
      '',
    ]
    logs.value.forEach((log, i) => {
      lines.push(`[${String(i + 1).padStart(3, '0')}] 告警时间：${log.fullTime || log.time}`)
      lines.push(`      告警等级：${levelName[log.level] || log.level}`)
      lines.push(`      告警类型：${log.type}${log.night ? '（夜间闭园巡查时段）' : ''}`)
      lines.push(`      告警内容：${log.message}`)
      lines.push(`      现场快照：${log.snapshot ? '已抓拍（系统内可查看）' : '无'}`)
      lines.push('')
    })
    lines.push('============================================================')
    lines.push('注：本日志由浏览器本地生成，AI 推理与抓拍数据均未上传任何服务器。')

    const blob = new Blob([lines.join('\r\n')], { type: 'text/plain;charset=utf-8' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `薪守疆隅告警日志_${new Date().toISOString().slice(0, 10)}.txt`
    a.click()
    URL.revokeObjectURL(url) // 释放临时对象URL
  }

  return {
    alarmLevel,
    logs,
    speak,
    setLevel,
    startAlarmSound,
    stopAlarmSound,
    addLog,
    clearLogs,
    exportLogs,
  }
}
