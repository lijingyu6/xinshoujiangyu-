import { ref, computed, onMounted, onUnmounted } from 'vue'

/**
 * usePatrol —— 无人值守智能安防巡查（24h 模拟时间轴）
 *
 * 时段划分：
 *   08:00–18:00 白天开放时段（正常参观监测）
 *   18:00–次日08:00 夜间闭园巡查模式（无人值守高灵敏度：
 *   闭园后画面中出现任何人员即判定为"夜间非法入侵"，直接严重告警）
 *
 * 两种时间来源：
 *   1) 真实时间：跟随本机系统时钟每秒刷新
 *   2) 模拟时间：拖动时间轴 / 点击快进按钮设置（答辩演示昼夜切换用），设置后自动切到模拟模式
 */

const DAY_START = 8 * 60 // 白天开放 08:00
const DAY_END = 18 * 60 // 夜间闭园 18:00

/** 取当前系统时间的分钟数 */
function nowMinutes() {
  const d = new Date()
  return d.getHours() * 60 + d.getMinutes()
}

/** 分钟数 → HH:MM 文案 */
export function formatMinutes(min) {
  const m = ((Math.round(min) % 1440) + 1440) % 1440
  return `${String(Math.floor(m / 60)).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}`
}

export function usePatrol() {
  const useRealTime = ref(true) // true=跟随系统时钟；false=手动模拟
  const simMinutes = ref(nowMinutes()) // 当前模拟/真实时间（分钟，0-1439）

  // 是否夜间闭园时段
  const isNight = computed(() => simMinutes.value < DAY_START || simMinutes.value >= DAY_END)
  // 时段文案
  const periodLabel = computed(() => (isNight.value ? '夜间闭园巡查模式' : '白天开放时段'))
  // 当前时刻 HH:MM
  const clockText = computed(() => formatMinutes(simMinutes.value))
  // 时间轴游标位置百分比（0-100）
  const cursorPercent = computed(() => (simMinutes.value / 1440) * 100)
  // 白天区段在时间轴上的起止百分比（供 UI 渲染亮/暗两段）
  const dayRange = { start: (DAY_START / 1440) * 100, end: (DAY_END / 1440) * 100 }

  let timer = null

  /** 设置模拟时间（拖动滑块 / 快进），自动切换为模拟时间来源 */
  function setSimMinutes(min) {
    useRealTime.value = false
    simMinutes.value = Math.min(1439, Math.max(0, Math.round(min)))
  }

  /** 时间快进（分钟），便于答辩演示昼夜切换 */
  function fastForward(deltaMin) {
    setSimMinutes(simMinutes.value + deltaMin)
  }

  /** 切回跟随系统真实时间 */
  function followRealTime() {
    useRealTime.value = true
    simMinutes.value = nowMinutes()
  }

  onMounted(() => {
    // 真实时间模式下每秒同步系统时钟
    timer = setInterval(() => {
      if (useRealTime.value) simMinutes.value = nowMinutes()
    }, 1000)
  })
  onUnmounted(() => clearInterval(timer))

  return {
    useRealTime,
    simMinutes,
    isNight,
    periodLabel,
    clockText,
    cursorPercent,
    dayRange,
    setSimMinutes,
    fastForward,
    followRealTime,
    formatMinutes,
  }
}
