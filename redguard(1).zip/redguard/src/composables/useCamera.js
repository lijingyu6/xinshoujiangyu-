import { ref, onUnmounted } from 'vue'

/**
 * useCamera —— 浏览器摄像头封装
 * 通过 MediaDevices API 打开/关闭本机摄像头；
 * 画面仅用于本地 AI 推理，全程不上传任何图像数据
 * @param {Function} getVideo 获取 <video> 元素的getter（组件挂载后可用）
 */
export function useCamera(getVideo) {
  const cameraOn = ref(false) // 摄像头是否已开启
  const cameraError = ref('') // 最近一次错误信息（用于界面提示）
  let stream = null // 当前媒体流引用

  /** 打开摄像头：申请视频权限并挂载媒体流到 <video> 元素 */
  async function openCamera() {
    cameraError.value = ''
    // 摄像头 API 要求 localhost / HTTPS 环境
    if (!navigator.mediaDevices?.getUserMedia) {
      cameraError.value = '当前环境不支持摄像头 API，请使用 localhost 或 HTTPS 访问'
      return false
    }
    try {
      stream = await navigator.mediaDevices.getUserMedia({
        video: { width: { ideal: 1280 }, height: { ideal: 720 }, facingMode: 'user' },
        audio: false,
      })
      const video = getVideo()
      if (!video) return false
      video.srcObject = stream
      await video.play()
      cameraOn.value = true
      return true
    } catch (err) {
      cameraError.value =
        '摄像头开启失败：' +
        (err.name === 'NotAllowedError'
          ? '用户拒绝了权限授权，请在浏览器地址栏重新允许'
          : err.name === 'NotFoundError'
            ? '未检测到可用摄像头设备'
            : err.message)
      return false
    }
  }

  /** 关闭摄像头：停止全部轨道并释放资源 */
  function closeCamera() {
    if (stream) stream.getTracks().forEach((t) => t.stop())
    stream = null
    const video = getVideo()
    if (video) video.srcObject = null
    cameraOn.value = false
  }

  // 组件卸载时释放摄像头
  onUnmounted(closeCamera)

  return { cameraOn, cameraError, openCamera, closeCamera }
}
