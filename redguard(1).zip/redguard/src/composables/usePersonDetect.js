import { ref, onUnmounted } from 'vue'
import * as tf from '@tensorflow/tfjs'
import * as cocoSsd from '@tensorflow-models/coco-ssd'

/**
 * usePersonDetect —— coco-ssd 人体检测封装
 * 模型加载与推理全部在浏览器本地完成（WebGL 加速），不经过任何服务器；
 * 推理结果保留全部类别：person 用于预警，其余类别作为"干扰目标"
 * 供【干扰过滤模拟开关】演示（动物/树木/风吹等干扰的过滤效果）
 */
export function usePersonDetect() {
  const modelLoading = ref(false) // 模型是否正在加载
  const modelReady = ref(false) // 模型是否就绪
  const modelError = ref('') // 模型加载错误信息
  const detections = ref([]) // 最近一帧检测结果 [{ bbox:[x,y,w,h], class, score }]

  let model = null // coco-ssd 模型实例
  let timer = null // 推理循环定时器
  let busy = false // 防重入标志（上一帧未推理完则跳过）

  /** 加载 coco-ssd 轻量模型（lite_mobilenet_v2，首次需联网拉取权重，之后走浏览器缓存） */
  async function loadModel() {
    if (modelReady.value || modelLoading.value) return
    modelLoading.value = true
    modelError.value = ''
    try {
      await tf.ready() // 确认 WebGL 后端就绪
      model = await cocoSsd.load({ base: 'lite_mobilenet_v2' })
      modelReady.value = true
    } catch (err) {
      modelError.value = 'AI 模型加载失败（请检查网络后刷新重试）：' + err.message
    } finally {
      modelLoading.value = false
    }
  }

  /** 启动推理循环：约 220ms/帧（≈4.5FPS），满足实时越界预警演示需求 */
  function startDetect(getVideo) {
    stopDetect()
    timer = setInterval(async () => {
      if (busy || !modelReady.value) return
      const video = getVideo()
      if (!video || !video.videoWidth) return
      busy = true
      try {
        // 最多返回 10 个目标，置信度阈值 0.45
        detections.value = await model.detect(video, 10, 0.45)
      } catch {
        /* 单帧推理失败可忽略，下一帧继续 */
      }
      busy = false
    }, 220)
  }

  /** 停止推理循环并清空检测结果 */
  function stopDetect() {
    if (timer) {
      clearInterval(timer)
      timer = null
    }
    detections.value = []
  }

  onUnmounted(stopDetect)

  return { modelLoading, modelReady, modelError, detections, loadModel, startDetect, stopDetect }
}
