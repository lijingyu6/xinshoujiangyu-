import { reactive, computed } from 'vue'

/**
 * useFenceDraw —— 虚拟电子围栏绘制 + 点在多边形判定
 * 三层围栏：warn 警戒区(黄) / danger 危险禁区(橙) / core 核心遗存保护区(红)
 * 多边形顶点使用【归一化坐标】(0~1)存储，与画面尺寸解耦，缩放不变形；
 * 配置可保存至 localStorage，刷新页面自动恢复
 */
export const FENCE_LEVELS = ['warn', 'danger', 'core']

// 本地持久化键名（围栏配置）
const FENCE_STORAGE_KEY = 'redguard_fences_v1'

export function useFenceDraw() {
  // 各等级已保存的多边形集合：{ warn: [[{x,y},...], ...], danger: [...], core: [...] }
  const fences = reactive({ warn: [], danger: [], core: [] })

  // 当前绘制状态：active 是否绘制中 / level 绘制等级 / points 已落点 / cursor 光标位置(橡皮筋)
  const drawing = reactive({ active: false, level: 'warn', points: [], cursor: null })

  // 各等级围栏数量统计（控制面板展示）
  const fenceCounts = computed(() => ({
    warn: fences.warn.length,
    danger: fences.danger.length,
    core: fences.core.length,
  }))

  /* ---------- 绘制流程 ---------- */

  /** 开始绘制指定等级的新围栏 */
  function startDraw(level) {
    drawing.active = true
    drawing.level = level
    drawing.points = []
    drawing.cursor = null
  }

  /** 落点：记录一个归一化顶点 */
  function addPoint(p) {
    if (!drawing.active || !p) return
    drawing.points.push(p)
  }

  /** 光标移动：更新橡皮筋预览终点 */
  function moveCursor(p) {
    if (drawing.active) drawing.cursor = p
  }

  /** 闭合多边形：过滤相邻重复点后存入对应等级集合 */
  function completeDraw() {
    if (!drawing.active) return null
    const pts = dedupePoints(drawing.points)
    if (pts.length < 3) {
      cancelDraw()
      return null
    }
    fences[drawing.level].push(pts)
    drawing.active = false
    drawing.points = []
    drawing.cursor = null
    return drawing.level
  }

  /** 取消当前绘制 */
  function cancelDraw() {
    drawing.active = false
    drawing.points = []
    drawing.cursor = null
  }

  /** 清空全部围栏（三层全清） */
  function clearFences() {
    FENCE_LEVELS.forEach((l) => (fences[l] = []))
  }

  /* ---------- 核心算法：射线法判断点是否在多边形内 ---------- */
  /**
   * Ray Casting 射线法：从目标点向右发射水平射线，
   * 统计与多边形边的交点数——奇数在内部，偶数在外部
   * @param {{x:number,y:number}} pt 归一化点（人体脚底中心）
   * @param {[{x:number,y:number}]} poly 归一化多边形顶点序列
   */
  function isPointInPolygon(pt, poly) {
    let inside = false
    for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
      const xi = poly[i].x, yi = poly[i].y
      const xj = poly[j].x, yj = poly[j].y
      const intersect =
        yi > pt.y !== yj > pt.y && pt.x < ((xj - xi) * (pt.y - yi)) / (yj - yi) + xi
      if (intersect) inside = !inside
    }
    return inside
  }

  /**
   * 评估人体落点命中等级：按 core > danger > warn 优先级返回最高命中级
   * @returns {'core'|'danger'|'warn'|null}
   */
  function evaluatePoint(pt) {
    if (fences.core.some((poly) => isPointInPolygon(pt, poly))) return 'core'
    if (fences.danger.some((poly) => isPointInPolygon(pt, poly))) return 'danger'
    if (fences.warn.some((poly) => isPointInPolygon(pt, poly))) return 'warn'
    return null
  }

  /* ---------- localStorage 持久化 ---------- */

  /** 保存围栏配置到 localStorage */
  function saveFences() {
    localStorage.setItem(FENCE_STORAGE_KEY, JSON.stringify(fences))
  }

  /** 页面初始化时恢复已保存的围栏配置 */
  function loadFences() {
    try {
      const data = JSON.parse(localStorage.getItem(FENCE_STORAGE_KEY))
      if (data) FENCE_LEVELS.forEach((l) => (fences[l] = Array.isArray(data[l]) ? data[l] : []))
    } catch {
      /* 配置损坏时忽略，使用空配置 */
    }
  }
  loadFences() // 初始化即恢复

  return {
    fences,
    drawing,
    fenceCounts,
    startDraw,
    addPoint,
    moveCursor,
    completeDraw,
    cancelDraw,
    clearFences,
    isPointInPolygon,
    evaluatePoint,
    saveFences,
    loadFences,
  }
}

/** 过滤相邻过近的重复点（双击闭合时会产生两个几乎重合的点） */
function dedupePoints(points) {
  const out = []
  for (const p of points) {
    const last = out[out.length - 1]
    if (last && Math.hypot(last.x - p.x, last.y - p.y) < 0.006) continue
    out.push(p)
  }
  return out
}
