import { reactive } from 'vue'

/**
 * useStudyGuard —— 研学队伍防走失防越界监管（红旅赛道专属）
 *
 * 三类安全事件（均带"持续帧确认 + 冷却时间"，防止 AI 单帧抖动误报）：
 *   1) stray   人员脱队：个体脚底点远离队伍质心，持续 ≥2s
 *   2) cross   越出参观围栏：人员脚底点进入核心遗存保护区（红色围栏）
 *   3) missing 人数缺失：画面检测人数 < 预设应到人数，持续 ≥5s
 *
 * 轨迹记录：coco-ssd 不提供人员跟踪 ID，单人轨迹不可靠，
 *           因此记录"队伍整体质心"的移动轨迹（归一化坐标，最近 48 个采样点）
 */

// 脱队判定：个体到队伍质心的归一化距离阈值（约画面宽度的 30%）
const STRAY_DISTANCE = 0.3
// 轨迹保留点数（约 4.5FPS × 48 ≈ 10 秒活动轨迹）
const TRAIL_MAX = 48
// 事件持续确认时长（毫秒）
const CONFIRM_STRAY_MS = 2000
const CONFIRM_MISSING_MS = 5000
// 同类事件告警冷却（毫秒）
const COOLDOWN = { stray: 15000, cross: 12000, missing: 20000 }

export function useStudyGuard() {
  const state = reactive({
    active: false, // 研学模式是否开启
    teamTotal: 30, // 预设队伍总人数（应到）
    presentCount: 0, // 当前画面检测人数（实到）
    missingCount: 0, // 缺失人数
    strayCount: 0, // 当前帧脱队人数
    strayIndices: [], // 当前帧脱队人员在传入 persons 数组中的下标（供画布标红）
    centroid: null, // 队伍质心 {x,y}（归一化脚底中心平均点）
    trail: [], // 质心轨迹点序列 [{x,y}]
    // 累计告警计数（控制面板展示，复位模式时清零）
    strayAlarmTotal: 0,
    crossAlarmTotal: 0,
    missingAlarmTotal: 0,
  })

  // 事件确认计时起点（0 表示当前不处于异常状态）
  let straySince = 0
  let missingSince = 0
  // 各类型最近一次告警时间戳（冷却控制）
  const lastFireAt = { stray: 0, cross: 0, missing: 0 }

  /**
   * 每帧评估研学队伍状态
   * @param {Array} persons 当前帧 person 检测结果（coco-ssd 原始结构，bbox 为视频像素坐标）
   * @param {number} vw 视频帧宽
   * @param {number} vh 视频帧高
   * @param {Function} evaluatePoint 围栏命中评估 (归一化点) => 'core'|'danger'|'warn'|null
   * @returns {Array<{key:string,level:string,type:string,message:string,speak:string}>}
   *          本帧需要上抛的告警事件（已做确认与冷却，通常为空数组）
   */
  function evaluate(persons, vw, vh, evaluatePoint) {
    const events = []
    if (!state.active || !vw || !vh) {
      // 非研学模式：清空瞬时状态（累计计数与轨迹保留）
      state.presentCount = 0
      state.missingCount = 0
      state.strayCount = 0
      state.strayIndices = []
      state.centroid = null
      return events
    }

    state.presentCount = persons.length
    state.missingCount = Math.max(0, state.teamTotal - persons.length)

    // ---------- 计算每名人员的脚底归一化点 ----------
    const feet = persons.map((d) => {
      const [x, y, w, h] = d.bbox
      return { x: (x + w / 2) / vw, y: (y + h) / vh }
    })

    // ---------- 队伍质心（脚底点平均值）----------
    if (feet.length) {
      const cx = feet.reduce((s, p) => s + p.x, 0) / feet.length
      const cy = feet.reduce((s, p) => s + p.y, 0) / feet.length
      state.centroid = { x: cx, y: cy }
      // 记录质心轨迹（与上一点过近则跳过，避免静止时刷满轨迹）
      const last = state.trail[state.trail.length - 1]
      if (!last || Math.hypot(last.x - cx, last.y - cy) > 0.01) {
        state.trail.push({ x: cx, y: cy })
        if (state.trail.length > TRAIL_MAX) state.trail.shift()
      }
    } else {
      state.centroid = null
    }

    // ---------- 事件1：人员脱队（距质心过远，持续确认） ----------
    const strayIdx = []
    if (feet.length >= 2) {
      // 单人不成队，至少 2 人时才做脱队判定（避免把唯一落单者误判为脱队）
      feet.forEach((p, i) => {
        if (state.centroid && Math.hypot(p.x - state.centroid.x, p.y - state.centroid.y) > STRAY_DISTANCE) {
          strayIdx.push(i)
        }
      })
    }
    state.strayIndices = strayIdx
    state.strayCount = strayIdx.length

    const now = Date.now()
    if (strayIdx.length > 0) {
      if (!straySince) straySince = now
      if (now - straySince >= CONFIRM_STRAY_MS && now - lastFireAt.stray >= COOLDOWN.stray) {
        lastFireAt.stray = now
        state.strayAlarmTotal++
        events.push({
          key: 'stray',
          level: 'danger',
          type: '研学人员脱队',
          message: `检测到 ${strayIdx.length} 名研学人员脱离队伍中心区域，请带队老师立即收拢队伍`,
          speak: '请注意，有研学同学脱离队伍，请立即回到队伍中来。',
        })
      }
    } else {
      straySince = 0 // 恢复正常，重新计时
    }

    // ---------- 事件2：越出参观围栏（任一人进入核心遗存保护区，立即上报） ----------
    let crossHit = false
    for (const p of feet) {
      if (evaluatePoint(p) === 'core') {
        crossHit = true
        break
      }
    }
    if (crossHit && now - lastFireAt.cross >= COOLDOWN.cross) {
      lastFireAt.cross = now
      state.crossAlarmTotal++
      events.push({
        key: 'cross',
        level: 'critical',
        type: '研学队伍越界',
        message: '研学队伍中检测到人员越过参观围栏、进入核心遗存保护区，请立即制止并清点人数',
        speak: '警告！研学队伍已越过参观围栏，请立即退回到参观区域！',
      })
    }

    // ---------- 事件3：人数缺失（实到 < 应到，持续确认） ----------
    if (state.missingCount > 0) {
      if (!missingSince) missingSince = now
      if (now - missingSince >= CONFIRM_MISSING_MS && now - lastFireAt.missing >= COOLDOWN.missing) {
        lastFireAt.missing = now
        state.missingAlarmTotal++
        events.push({
          key: 'missing',
          level: 'danger',
          type: '研学人数缺失',
          message: `应到 ${state.teamTotal} 人，画面实到 ${state.presentCount} 人，缺失 ${state.missingCount} 人，请立即清点排查`,
          speak: `人数告警，应到${state.teamTotal}人，当前缺少${state.missingCount}人，请立即清点队伍。`,
        })
      }
    } else {
      missingSince = 0
    }

    return events
  }

  /** 清空轨迹与累计计数（关闭研学模式时调用） */
  function reset() {
    state.presentCount = 0
    state.missingCount = 0
    state.strayCount = 0
    state.strayIndices = []
    state.centroid = null
    state.trail = []
    state.strayAlarmTotal = 0
    state.crossAlarmTotal = 0
    state.missingAlarmTotal = 0
    straySince = 0
    missingSince = 0
  }

  return { state, evaluate, reset, STRAY_DISTANCE }
}
