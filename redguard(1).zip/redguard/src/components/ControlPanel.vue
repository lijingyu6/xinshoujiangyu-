<script setup>
/**
 * ControlPanel.vue —— 右侧白色卡片控制面板（四页签版）
 * 页签：① 监测监控 ② 围栏工具 ③ 研学监管 ④ 值守巡查
 * 业务逻辑与UI视图分离：状态 props 下发，操作 emit / v-model 上抛
 */
import { ref } from 'vue'

const props = defineProps({
  cameraOn: Boolean,
  modelLoading: Boolean,
  modelReady: Boolean,
  personCount: { type: Number, default: 0 },
  alarmLevel: { type: String, default: 'none' },
  activeLevel: { type: String, default: 'warn' },
  fenceCounts: { type: Object, default: () => ({ warn: 0, danger: 0, core: 0 }) },
  drawingActive: Boolean,
  interferenceFilter: Boolean,
  studyMode: Boolean,
  teamTotal: { type: Number, default: 30 },
  activeMode: { type: String, default: 'normal' },
  // 【阶段4】研学实时监管状态（useStudyGuard.state）
  study: {
    type: Object,
    default: () => ({
      presentCount: 0, missingCount: 0, strayCount: 0,
      strayAlarmTotal: 0, crossAlarmTotal: 0, missingAlarmTotal: 0,
    }),
  },
  // 【阶段4】24h 巡查时间轴状态（usePatrol 返回的响应式字段集合）
  patrol: {
    type: Object,
    default: () => ({
      simMinutes: 0, useRealTime: true, isNight: false,
      periodLabel: '', clockText: '00:00', cursorPercent: 0,
      dayRange: { start: 0, end: 100 },
    }),
  },
})

const emit = defineEmits([
  'open-camera',
  'close-camera',
  'update:activeLevel',
  'start-draw',
  'cancel-draw',
  'save-fences',
  'clear-fences',
  'update:interferenceFilter',
  'update:studyMode',
  'update:teamTotal',
  'update:activeMode',
  'patrol-set-time', // 拖动时间轴设置模拟时间（分钟）
  'patrol-follow-real', // 切回真实系统时间
  'patrol-fast-forward', // 时间快进（分钟）
])

/* ---------- 页签 ---------- */
const activeTab = ref('monitor')
const tabs = [
  { key: 'monitor', name: '监测监控', icon: 'fa-video' },
  { key: 'fence', name: '围栏工具', icon: 'fa-draw-polygon' },
  { key: 'study', name: '研学监管', icon: 'fa-users' },
  { key: 'patrol', name: '值守巡查', icon: 'fa-satellite-dish' },
]

/* ---------- 配置数据 ---------- */
const fenceLevels = [
  { key: 'warn', name: '警戒区', color: '#F59E0B', desc: '进入播报温馨劝阻' },
  { key: 'danger', name: '危险禁区', color: '#EA580C', desc: '踏入声光闪烁告警' },
  { key: 'core', name: '核心遗存保护区', color: '#DC2626', desc: '闯入强声光告警+写日志' },
]
const modes = [
  { key: 'normal', name: '普通监测模式', icon: 'fa-shield-halved', desc: '日常防越界' },
  { key: 'study', name: '研学模式', icon: 'fa-users', desc: '队伍防走失监管' },
  { key: 'unattended', name: '无人值守模式', icon: 'fa-satellite-dish', desc: '24h 循环巡查' },
]
const ALARM_TEXT = {
  none: { text: '无', color: '#6B7280' },
  warn: { text: '一级·警戒', color: '#F59E0B' },
  danger: { text: '二级·危险', color: '#EA580C' },
  core: { text: '三级·严重', color: '#DC2626' },
}

// 时间轴刻度（0/6/12/18/24 时）
const axisTicks = [0, 6, 12, 18, 24]
</script>

<template>
  <div class="h-full bg-white rounded-xl shadow-shrine ring-1 ring-china-red/15 flex flex-col overflow-hidden">
    <!-- 四页签导航 -->
    <div class="shrink-0 flex border-b border-red-100 bg-gradient-to-r from-red-50 to-white">
      <button
        v-for="t in tabs"
        :key="t.key"
        class="relative flex-1 py-3 text-[13px] font-bold transition
               flex items-center justify-center gap-1.5"
        :class="activeTab === t.key ? 'text-china-red' : 'text-gray-400 hover:text-gray-600'"
        @click="activeTab = t.key"
      >
        <i :class="['fa-solid', t.icon]"></i>{{ t.name }}
        <span
          class="absolute bottom-0 left-1/2 -translate-x-1/2 h-0.5 rounded-full bg-china-red
                 transition-all duration-300"
          :class="activeTab === t.key ? 'w-3/4 opacity-100' : 'w-0 opacity-0'"
        ></span>
      </button>
    </div>

    <div class="flex-1 overflow-y-auto p-5">
      <!-- ===== 页签一：监测监控 ===== -->
      <div v-if="activeTab === 'monitor'" class="flex flex-col gap-5">
        <section class="rounded-xl border border-gray-100 p-4 bg-gray-50/60">
          <h3 class="module-title"><i class="fa-solid fa-video"></i>摄像头控制</h3>
          <div class="flex gap-2.5">
            <button
              class="flex-1 py-2.5 rounded-lg text-sm font-bold text-white bg-china-red
                     hover:bg-[#a3122c] transition shadow disabled:opacity-40 disabled:cursor-not-allowed"
              :disabled="cameraOn"
              @click="emit('open-camera')"
            >
              <i class="fa-solid fa-power-off mr-1"></i>开启摄像头
            </button>
            <button
              class="flex-1 py-2.5 rounded-lg text-sm font-bold text-gray-600 bg-white
                     border border-gray-300 hover:bg-gray-100 transition
                     disabled:opacity-40 disabled:cursor-not-allowed"
              :disabled="!cameraOn"
              @click="emit('close-camera')"
            >
              <i class="fa-solid fa-stop mr-1"></i>关闭摄像头
            </button>
          </div>
          <p
            class="mt-3 text-xs"
            :class="modelReady ? 'text-emerald-600' : modelLoading ? 'text-amber-600' : 'text-gray-400'"
          >
            <i
              :class="['fa-solid mr-1', modelReady ? 'fa-circle-check' : modelLoading ? 'fa-spinner fa-spin' : 'fa-circle-info']"
            ></i>
            AI 人体检测模型：{{ modelReady ? '已就绪（本地推理）' : modelLoading ? '加载中…' : '待加载（开启摄像头时自动加载）' }}
          </p>
        </section>

        <section class="rounded-xl border border-gray-100 p-4 bg-gray-50/60">
          <h3 class="module-title"><i class="fa-solid fa-gauge-high"></i>实时状态面板</h3>
          <div class="grid grid-cols-2 gap-3">
            <div class="rounded-xl bg-white border border-gray-100 p-4 text-center shadow-sm">
              <p class="text-xs text-gray-500 mb-1.5">实时检测人数</p>
              <p class="text-3xl font-extrabold text-china-red">{{ personCount }}</p>
              <p class="text-[10px] text-gray-400 mt-1">AI 画面人体目标</p>
            </div>
            <div class="rounded-xl bg-white border border-gray-100 p-4 text-center shadow-sm">
              <p class="text-xs text-gray-500 mb-1.5">当前告警等级</p>
              <p class="text-xl font-extrabold mt-1" :style="{ color: ALARM_TEXT[alarmLevel].color }">
                {{ ALARM_TEXT[alarmLevel].text }}
              </p>
              <p class="text-[10px] text-gray-400 mt-1.5">
                {{ alarmLevel === 'none' ? '运行平稳' : '声光联动已触发' }}
              </p>
            </div>
          </div>
        </section>
      </div>

      <!-- ===== 页签二：围栏工具 ===== -->
      <div v-else-if="activeTab === 'fence'" class="flex flex-col gap-5">
        <section class="rounded-xl border border-gray-100 p-4 bg-gray-50/60">
          <h3 class="module-title"><i class="fa-solid fa-layer-group"></i>围栏等级选择</h3>
          <div class="flex flex-col gap-2">
            <button
              v-for="lv in fenceLevels"
              :key="lv.key"
              class="flex items-center justify-between px-3.5 py-2.5 rounded-lg border-2 transition
                     disabled:opacity-40"
              :class="activeLevel === lv.key
                ? 'text-white border-transparent shadow font-bold'
                : 'bg-white text-gray-600 border-gray-200 hover:border-gray-300'"
              :style="activeLevel === lv.key ? { backgroundColor: lv.color } : {}"
              :disabled="drawingActive"
              @click="emit('update:activeLevel', lv.key)"
            >
              <span class="text-sm">
                <i :class="activeLevel === lv.key ? 'fa-solid fa-circle-dot mr-2' : 'fa-regular fa-circle mr-2'"></i>
                {{ lv.name }}
              </span>
              <span class="text-[10px]" :class="activeLevel === lv.key ? 'text-white/85' : 'text-gray-400'">
                {{ lv.desc }}
              </span>
            </button>
          </div>
          <p class="mt-3 text-xs text-gray-400">
            已存围栏：警戒 {{ fenceCounts.warn }} · 危险 {{ fenceCounts.danger }} · 核心 {{ fenceCounts.core }}
          </p>
        </section>

        <section class="rounded-xl border border-gray-100 p-4 bg-gray-50/60">
          <h3 class="module-title"><i class="fa-solid fa-pen-ruler"></i>绘制操作</h3>
          <div class="flex gap-2.5 mb-3">
            <button
              v-if="!drawingActive"
              class="tool-btn grow py-2.5"
              :disabled="!cameraOn"
              @click="emit('start-draw')"
            >
              <i class="fa-solid fa-plus"></i>新增围栏
            </button>
            <button
              v-else
              class="grow py-2.5 rounded-lg text-sm font-bold text-white bg-alarm-orange
                     hover:bg-orange-600 transition animate-pulse"
              @click="emit('cancel-draw')"
            >
              <i class="fa-solid fa-ban mr-1"></i>绘制中·点击取消
            </button>
            <button class="tool-btn grow py-2.5" @click="emit('save-fences')">
              <i class="fa-solid fa-floppy-disk"></i>保存围栏
            </button>
          </div>
          <button
            class="w-full py-2.5 rounded-lg text-sm font-bold bg-white text-alarm-red
                   border border-alarm-red/40 hover:bg-red-50 transition"
            @click="emit('clear-fences')"
          >
            <i class="fa-solid fa-trash-can mr-1"></i>清空全部围栏
          </button>
        </section>

        <section class="rounded-xl border border-gray-100 p-4 bg-gray-50/60">
          <h3 class="module-title"><i class="fa-solid fa-filter"></i>智能识别设置</h3>
          <label class="flex items-center justify-between cursor-pointer select-none">
            <span class="text-xs text-gray-600 leading-relaxed">
              干扰过滤模拟
              <span class="block text-[10px] text-gray-400 mt-0.5">开启后过滤动物、树木、风吹等非人员干扰目标</span>
            </span>
            <input
              :checked="interferenceFilter"
              type="checkbox"
              class="sr-only"
              @change="emit('update:interferenceFilter', $event.target.checked)"
            />
            <span class="relative w-10 h-5 rounded-full transition shrink-0" :class="interferenceFilter ? 'bg-china-red' : 'bg-gray-300'">
              <span
                class="absolute top-0.5 w-4 h-4 rounded-full bg-white shadow transition-all"
                :class="interferenceFilter ? 'left-[22px]' : 'left-0.5'"
              ></span>
            </span>
          </label>
        </section>
      </div>

      <!-- ===== 页签三：研学监管 ===== -->
      <div v-else-if="activeTab === 'study'" class="flex flex-col gap-5">
        <section class="rounded-xl border border-gray-100 p-4 bg-gray-50/60">
          <h3 class="module-title"><i class="fa-solid fa-users"></i>研学管控设置</h3>
          <div class="flex items-center gap-2.5 mb-4">
            <label class="text-xs text-gray-600 shrink-0">队伍总人数</label>
            <input
              :value="teamTotal"
              type="number"
              min="1"
              max="99"
              class="w-20 px-2 py-2 rounded-lg border border-gray-300 text-sm text-center
                     focus:outline-none focus:ring-2 focus:ring-china-red/40 focus:border-china-red"
              @input="emit('update:teamTotal', Number($event.target.value) || 1)"
            />
            <span class="text-[11px] text-gray-400">人（预设应到）</span>
          </div>
          <label class="flex items-center justify-between cursor-pointer select-none">
            <span class="text-xs text-gray-600 leading-relaxed">
              研学模式开关
              <span class="block text-[10px] text-gray-400 mt-0.5">开启后实时统计人数、标记脱队、记录队伍中心轨迹</span>
            </span>
            <input
              :checked="studyMode"
              type="checkbox"
              class="sr-only"
              @change="emit('update:studyMode', $event.target.checked)"
            />
            <span class="relative w-10 h-5 rounded-full transition shrink-0" :class="studyMode ? 'bg-china-red' : 'bg-gray-300'">
              <span
                class="absolute top-0.5 w-4 h-4 rounded-full bg-white shadow transition-all"
                :class="studyMode ? 'left-[22px]' : 'left-0.5'"
              ></span>
            </span>
          </label>
        </section>

        <!-- 实时队伍数据（未开启研学模式时置灰提示） -->
        <section
          class="rounded-xl border p-4 transition"
          :class="studyMode ? 'border-amber-200 bg-amber-50/60' : 'border-gray-100 bg-gray-50/60'"
        >
          <h3 class="module-title"><i class="fa-solid fa-children"></i>队伍实时数据</h3>
          <div class="grid grid-cols-3 gap-2 mb-3">
            <div class="rounded-lg bg-white border border-gray-100 p-3 text-center">
              <p class="text-[10px] text-gray-500">应到</p>
              <p class="text-xl font-extrabold text-gray-700">{{ teamTotal }}</p>
            </div>
            <div class="rounded-lg bg-white border border-gray-100 p-3 text-center">
              <p class="text-[10px] text-gray-500">画面实到</p>
              <p class="text-xl font-extrabold text-emerald-600">
                {{ studyMode ? study.presentCount : '—' }}
              </p>
            </div>
            <div class="rounded-lg bg-white border p-3 text-center"
                 :class="studyMode && study.missingCount > 0 ? 'border-alarm-orange' : 'border-gray-100'">
              <p class="text-[10px] text-gray-500">缺失人数</p>
              <p class="text-xl font-extrabold"
                 :class="studyMode && study.missingCount > 0 ? 'text-alarm-orange' : 'text-gray-700'">
                {{ studyMode ? study.missingCount : '—' }}
              </p>
            </div>
          </div>
          <!-- 累计告警计数 -->
          <div class="rounded-lg bg-white border border-gray-100 p-3">
            <p class="text-[11px] font-bold text-gray-600 mb-2">
              <i class="fa-solid fa-triangle-exclamation text-alarm-orange mr-1"></i>脱队 / 越界 / 缺失 告警计数
            </p>
            <div class="flex items-center justify-around text-center">
              <div>
                <p class="text-lg font-extrabold text-alarm-orange">{{ studyMode ? study.strayAlarmTotal : 0 }}</p>
                <p class="text-[10px] text-gray-400">脱队告警</p>
              </div>
              <div class="w-px h-7 bg-gray-200"></div>
              <div>
                <p class="text-lg font-extrabold text-alarm-red">{{ studyMode ? study.crossAlarmTotal : 0 }}</p>
                <p class="text-[10px] text-gray-400">越界告警</p>
              </div>
              <div class="w-px h-7 bg-gray-200"></div>
              <div>
                <p class="text-lg font-extrabold text-amber-500">{{ studyMode ? study.missingAlarmTotal : 0 }}</p>
                <p class="text-[10px] text-gray-400">缺失告警</p>
              </div>
            </div>
          </div>
          <p v-if="!studyMode" class="mt-3 text-[11px] text-gray-400 text-center">
            打开上方"研学模式开关"开始队伍监管
          </p>
          <p v-else class="mt-3 text-[11px] text-amber-700/80 leading-relaxed">
            <i class="fa-solid fa-circle-info mr-1"></i>
            画面中金色圆点为队伍中心，拖尾为中心移动轨迹；脱队人员显示橙色框并与中心连线。
          </p>
        </section>
      </div>

      <!-- ===== 页签四：值守巡查 ===== -->
      <div v-else class="flex flex-col gap-5">
        <!-- 系统模式切换 -->
        <section class="rounded-xl border border-gray-100 p-4 bg-gray-50/60">
          <h3 class="module-title"><i class="fa-solid fa-toggle-on"></i>系统模式切换</h3>
          <div class="flex flex-col gap-2">
            <button
              v-for="m in modes"
              :key="m.key"
              class="flex items-center justify-between px-3.5 py-3 rounded-lg text-sm border-2 transition"
              :class="activeMode === m.key
                ? 'border-china-red bg-red-50 text-china-red font-bold'
                : 'border-gray-200 bg-white text-gray-600 hover:border-china-red/40'"
              @click="emit('update:activeMode', m.key)"
            >
              <span><i :class="['fa-solid mr-2', m.icon]"></i>{{ m.name }}</span>
              <span class="text-[10px] text-gray-400 font-normal">{{ m.desc }}</span>
            </button>
          </div>
        </section>

        <!-- 24h 模拟时间轴 -->
        <section class="rounded-xl border border-gray-100 p-4 bg-gray-50/60">
          <h3 class="module-title"><i class="fa-solid fa-clock"></i>24 小时巡查时间轴</h3>

          <!-- 当前时段状态 -->
          <div class="flex items-center justify-between mb-3">
            <div class="flex items-center gap-2">
              <span
                class="w-9 h-9 rounded-full flex items-center justify-center text-white shadow"
                :class="patrol.isNight ? 'bg-indigo-700' : 'bg-amber-500'"
              >
                <i :class="['fa-solid', patrol.isNight ? 'fa-moon' : 'fa-sun']"></i>
              </span>
              <div>
                <p class="text-sm font-bold" :class="patrol.isNight ? 'text-indigo-700' : 'text-amber-600'">
                  {{ patrol.periodLabel }}
                </p>
                <p class="text-[10px] text-gray-400">
                  {{ patrol.useRealTime ? '跟随系统真实时间' : '模拟时间（答辩演示用）' }}
                </p>
              </div>
            </div>
            <p class="text-2xl font-extrabold font-mono" :class="patrol.isNight ? 'text-indigo-700' : 'text-amber-600'">
              {{ patrol.clockText }}
            </p>
          </div>

          <!-- 时间轴轨道：0-8 夜 / 8-18 昼 / 18-24 夜 -->
          <div class="relative h-7 rounded-full overflow-hidden flex">
            <div class="h-full bg-indigo-900/80" :style="{ width: `100%` }"></div>
            <!-- 用绝对定位白天段覆盖 -->
            <div
              class="absolute top-0 h-full bg-amber-300/80"
              :style="{ left: patrol.dayRange.start + '%', width: patrol.dayRange.end - patrol.dayRange.start + '%' }"
            ></div>
            <!-- 当前时刻游标 -->
            <div
              class="absolute top-0 h-full w-0.5 bg-china-red shadow-[0_0_8px_rgba(196,30,58,0.9)]"
              :style="{ left: patrol.cursorPercent + '%' }"
            >
              <span class="absolute -top-0 -translate-x-1/2 w-3 h-3 rounded-full bg-china-red border-2 border-white"></span>
            </div>
          </div>
          <!-- 刻度 -->
          <div class="relative h-4 mt-1 text-[9px] text-gray-400 font-mono">
            <span
              v-for="tick in axisTicks"
              :key="tick"
              class="absolute -translate-x-1/2"
              :style="{ left: (tick / 24) * 100 + '%' }"
            >{{ String(tick).padStart(2, '0') }}</span>
          </div>

          <!-- 时间拖动条 -->
          <input
            type="range"
            min="0"
            max="1439"
            :value="patrol.simMinutes"
            class="w-full mt-1 accent-[#C41E3A] cursor-pointer"
            @input="emit('patrol-set-time', Number($event.target.value))"
          />

          <!-- 时间操作按钮 -->
          <div class="grid grid-cols-3 gap-2 mt-3">
            <button
              class="py-2 rounded-lg text-xs font-bold bg-white text-gray-600 border border-gray-300
                     hover:bg-gray-100 transition"
              @click="emit('patrol-fast-forward', 30)"
            >
              <i class="fa-solid fa-forward mr-1"></i>快进 30 分
            </button>
            <button
              class="py-2 rounded-lg text-xs font-bold bg-white text-gray-600 border border-gray-300
                     hover:bg-gray-100 transition"
              @click="emit('patrol-fast-forward', 180)"
            >
              <i class="fa-solid fa-forward-fast mr-1"></i>快进 3 时
            </button>
            <button
              class="py-2 rounded-lg text-xs font-bold text-china-red bg-white
                     border border-china-red/40 hover:bg-red-50 transition"
              :disabled="patrol.useRealTime"
              @click="emit('patrol-follow-real')"
            >
              <i class="fa-solid fa-clock-rotate-left mr-1"></i>真实时间
            </button>
          </div>

          <!-- 无人值守说明 -->
          <div
            class="mt-3 rounded-lg border p-3 text-[11px] leading-relaxed"
            :class="activeMode === 'unattended' ? 'border-indigo-300 bg-indigo-50 text-indigo-800' : 'border-gray-200 bg-white text-gray-500'"
          >
            <p class="font-bold mb-1">
              <i class="fa-solid fa-satellite-dish mr-1"></i>无人值守巡查策略
            </p>
            白天开放时段：执行常规三级围栏预警；夜间闭园时段切换高灵敏度，
            画面中<span class="font-bold">出现任何人员即判定为非法入侵</span>，触发强声光告警、抓拍快照并写入日志，可持续循环监测。
          </div>
        </section>
      </div>
    </div>
  </div>
</template>

<style scoped>
.module-title {
  @apply flex items-center gap-2 text-sm font-bold text-gray-700 mb-3 pl-2 border-l-4 border-china-red;
}
.tool-btn {
  @apply rounded-lg text-sm font-bold bg-white text-china-red
         border border-china-red/40 hover:bg-red-50 transition
         disabled:opacity-40 disabled:cursor-not-allowed;
}
</style>
