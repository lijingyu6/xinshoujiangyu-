<script setup>
/**
 * AlarmLogPanel.vue —— 页面底部通栏：告警日志滚动列表（阶段4 完整版）
 * - 记录告警时间、告警等级、告警类型；条目红色高亮
 * - Canvas 告警快照：行内缩略图，点击弹出大图预览
 * - 日志文本导出（.txt）与清空
 */
import { ref } from 'vue'

defineProps({
  // 告警日志：{ id, time, fullTime, level, type, message, snapshot, night }
  logs: { type: Array, default: () => [] },
})

const emit = defineEmits(['clear', 'export'])

// 快照大图预览：当前选中的日志条目（null 表示关闭弹层）
const previewLog = ref(null)

// 告警等级徽标样式映射
const LEVEL_STYLE = {
  info: { label: '劝阻提示', cls: 'bg-amber-100 text-amber-700 border-amber-300' },
  danger: { label: '危险告警', cls: 'bg-orange-100 text-orange-700 border-orange-300' },
  critical: { label: '严重告警', cls: 'bg-red-100 text-red-700 border-red-300' },
}
</script>

<template>
  <footer class="h-44 shrink-0 mx-4 mb-4 bg-white rounded-xl shadow-shrine ring-1 ring-china-red/15 flex flex-col overflow-hidden">
    <!-- 日志面板头部 -->
    <div class="shrink-0 px-4 py-2 flex items-center justify-between border-b border-red-100
                bg-gradient-to-r from-red-50 to-white">
      <h2 class="text-sm font-bold text-gray-800 tracking-wider">
        <i class="fa-solid fa-clipboard-list text-china-red mr-1.5"></i>告警日志
        <span class="ml-2 text-[11px] font-normal text-gray-400">
          告警时间 · 告警等级 · 告警类型 · Canvas 快照（共 {{ logs.length }} 条，本地持久化）
        </span>
      </h2>
      <div class="flex gap-2">
        <button
          class="px-3 py-1 rounded-md text-xs font-bold text-china-red bg-white
                 border border-china-red/40 hover:bg-red-50 transition
                 disabled:opacity-40 disabled:cursor-not-allowed"
          :disabled="logs.length === 0"
          @click="emit('export')"
        >
          <i class="fa-solid fa-file-arrow-down mr-1"></i>导出日志
        </button>
        <button
          class="px-3 py-1 rounded-md text-xs font-bold text-gray-500 bg-white
                 border border-gray-300 hover:bg-gray-100 transition
                 disabled:opacity-40 disabled:cursor-not-allowed"
          :disabled="logs.length === 0"
          @click="emit('clear')"
        >
          <i class="fa-solid fa-broom mr-1"></i>清空日志
        </button>
      </div>
    </div>

    <!-- 日志列表 -->
    <div v-if="logs.length" class="flex-1 overflow-y-auto px-3 py-2 flex flex-col gap-1.5">
      <div
        v-for="log in logs"
        :key="log.id"
        class="animate-log-in flex items-center gap-3 px-3 py-1.5 rounded-lg
               border border-red-200 bg-red-50/80 hover:bg-red-100/80 transition"
      >
        <!-- 告警时间 -->
        <span class="text-xs font-mono text-gray-500 shrink-0">
          <i class="fa-regular fa-clock mr-1"></i>{{ log.time }}
        </span>
        <!-- 夜间标识 -->
        <span
          v-if="log.night"
          class="shrink-0 px-1.5 py-0.5 rounded text-[10px] font-bold bg-indigo-100 text-indigo-700 border border-indigo-300"
          title="夜间闭园巡查时段"
        >
          <i class="fa-solid fa-moon mr-0.5"></i>夜间
        </span>
        <!-- 告警等级徽标 -->
        <span
          :class="['px-2 py-0.5 rounded-full text-[11px] font-bold border shrink-0',
                   LEVEL_STYLE[log.level]?.cls || LEVEL_STYLE.info.cls]"
        >
          {{ LEVEL_STYLE[log.level]?.label || '提示' }}
        </span>
        <!-- 告警类型与内容 -->
        <span class="text-sm font-bold text-red-700 shrink-0">【{{ log.type }}】</span>
        <span class="text-xs text-gray-700 truncate flex-1">{{ log.message }}</span>
        <!-- 快照缩略图：点击查看大图 -->
        <button
          v-if="log.snapshot"
          class="shrink-0 w-16 h-9 rounded border border-red-300 overflow-hidden
                 hover:ring-2 hover:ring-china-red transition relative group"
          title="点击查看告警现场快照"
          @click="previewLog = log"
        >
          <img :src="log.snapshot" alt="告警快照" class="w-full h-full object-cover" />
          <span class="absolute inset-0 flex items-center justify-center bg-black/40
                       opacity-0 group-hover:opacity-100 transition text-white text-[10px]">
            <i class="fa-solid fa-magnifying-glass-plus"></i>
          </span>
        </button>
        <span v-else class="shrink-0 text-[11px] text-gray-300">
          <i class="fa-solid fa-camera-slash"></i> 无快照
        </span>
      </div>
    </div>

    <!-- 空状态 -->
    <div v-else class="flex-1 flex flex-col items-center justify-center gap-1 text-gray-400">
      <p class="text-sm">
        <i class="fa-solid fa-shield-heart text-emerald-500 mr-1.5"></i>
        暂无告警记录，红色遗址一切平安
      </p>
      <p class="text-[11px] tracking-wider">越界闯入 / 人员脱队 / 人数缺失 / 夜间入侵事件将自动记录于此并本地留存</p>
    </div>

    <!-- 快照大图预览弹层 -->
    <Teleport to="body">
      <div
        v-if="previewLog"
        class="fixed inset-0 z-[60] flex items-center justify-center bg-black/75 backdrop-blur-sm p-8"
        @click.self="previewLog = null"
      >
        <div class="max-w-3xl w-full bg-white rounded-xl overflow-hidden shadow-2xl">
          <!-- 弹层头部 -->
          <div class="px-4 py-3 flex items-center justify-between bg-china-red text-white">
            <h3 class="font-bold text-sm tracking-wider">
              <i class="fa-solid fa-camera-retro mr-1.5"></i>告警现场快照
            </h3>
            <button class="w-7 h-7 rounded-full hover:bg-white/20 transition" @click="previewLog = null">
              <i class="fa-solid fa-xmark"></i>
            </button>
          </div>
          <!-- 快照图片 -->
          <img :src="previewLog.snapshot" alt="告警现场快照" class="w-full max-h-[60vh] object-contain bg-black" />
          <!-- 快照信息 -->
          <div class="p-4 text-sm">
            <p class="mb-1">
              <span
                :class="['px-2 py-0.5 rounded-full text-[11px] font-bold border mr-2',
                         LEVEL_STYLE[previewLog.level]?.cls || LEVEL_STYLE.info.cls]"
              >{{ LEVEL_STYLE[previewLog.level]?.label || '提示' }}</span>
              <span class="font-bold text-red-700">【{{ previewLog.type }}】</span>
              <span v-if="previewLog.night" class="ml-2 text-[10px] text-indigo-600">
                <i class="fa-solid fa-moon mr-0.5"></i>夜间闭园巡查时段
              </span>
            </p>
            <p class="text-xs text-gray-600 mb-1">{{ previewLog.message }}</p>
            <p class="text-[11px] text-gray-400 font-mono">
              <i class="fa-regular fa-clock mr-1"></i>{{ previewLog.fullTime || previewLog.time }}
            </p>
          </div>
        </div>
      </div>
    </Teleport>
  </footer>
</template>
