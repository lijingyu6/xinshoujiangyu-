<script setup>
/**
 * VideoCanvas.vue —— 摄像头 + Canvas 绘制组件（视图层）
 * video 播放摄像头画面；canvas 绝对覆盖上层（object-fit:cover 与视频对齐），
 * 绘制内容：三层围栏多边形 / 绘制橡皮筋预览 / 人体检测框 / 干扰目标 / 告警特效
 * 业务逻辑与UI视图分离：本组件只负责渲染与鼠标事件采集，
 * 坐标归一化后通过 emit 上抛，由 App.vue 调用业务组合式函数处理
 *
 * ★本次修复（电子围栏画布点击失效）：
 *   修复点1 DOM 层级：canvas pointer-events:auto 置顶接收事件，video pointer-events:none 不拦截；
 *                     纯展示类覆盖层（图例/角标/提示条）一律 pointer-events:none 透传
 *   修复点2 坐标转换：按 offsetParent 链累计 offsetLeft/offsetTop，并做 cover 缩放逆变换，消除位置偏移
 *   修复点3 状态校验：isDrawingFence 单一事实源，仅绘制态响应左键/双击/右键/移动
 *   修复点4 交互逻辑：左键落点；双击 或 点击靠近首点（≥3点）自动闭合；右键清空本次顶点并取消
 *   修复点5 实时渲染：落点后立即 drawFrame() 同步重绘（同时保留 rAF 循环支撑橡皮筋/呼吸动画）
 *   修复点6 原有能力保留：三层围栏配色/保存/pointInPolygon（useFenceDraw）/告警日志均未改动
 */
import { ref, computed, onMounted, onUnmounted } from 'vue'

const props = defineProps({
  cameraOn: Boolean, // 摄像头是否开启
  fences: { type: Object, required: true }, // 已保存围栏 {warn:[],danger:[],core:[]}（归一化坐标）
  drawing: { type: Object, required: true }, // 绘制状态 {active,level,points,cursor}
  detections: { type: Array, default: () => [] }, // 最近一帧检测（视频像素坐标）
  interferenceFilter: Boolean, // 干扰过滤开关：开启时隐藏非person目标
  alarmLevel: { type: String, default: 'none' }, // 当前告警等级
  errorMsg: { type: String, default: '' }, // 摄像头/模型错误提示
  // —— 阶段4：研学监管 + 夜间巡查 ——
  studyActive: Boolean, // 研学模式是否开启（开启时绘制队伍质心/轨迹/脱队标记）
  studyInfo: {
    type: Object,
    default: () => ({ centroid: null, trail: [], strayBoxes: [] }),
  }, // 研学绘制数据：质心{ x,y }、轨迹[{x,y}]、脱队人员 bbox 引用数组
  nightMode: Boolean, // 是否夜间闭园巡查模式（画面叠加暗色夜视滤镜）
  clockText: { type: String, default: '' }, // 当前时段时刻 HH:MM（夜间角标显示）
})

const emit = defineEmits([
  'point-add', // 左键落点（归一化坐标）
  'draw-complete', // 双击 / 点击首点附近闭合
  'draw-cancel', // 右键取消本次绘制
  'cursor-move', // 光标移动（橡皮筋预览）
  'quick-camera', // 悬浮工具条：开启/关闭摄像头
  'demo-alarm', // 悬浮工具条：模拟告警演示（warn/danger/core）
])

// 对父组件暴露 <video> 元素与快照抓拍方法（供 useCamera / usePersonDetect / 告警快照使用）
const videoRef = ref(null)
const canvasRef = ref(null)

/**
 * 【阶段4】告警快照抓拍：将视频帧 + 围栏/检测覆盖层合成为一张 JPEG dataURL
 * - 摄像头媒体流与 canvas 同源，不会造成画布污染，可正常 toDataURL
 * - 摄像头未开启时以深色底 + 覆盖层合成（保证演示按钮也能生成快照）
 * - 顶部叠加红色水印条：系统名 + 抓拍时间
 * @returns {string|null} JPEG dataURL
 */
function captureSnapshot() {
  const overlay = canvasRef.value
  const video = videoRef.value
  const w = overlay?.width || 1280
  const h = overlay?.height || 720
  const out = document.createElement('canvas')
  out.width = w
  out.height = h
  const ctx = out.getContext('2d')
  try {
    // 1) 视频底图（无视频流时填充深色底）
    if (video && video.videoWidth) {
      ctx.drawImage(video, 0, 0, w, h)
    } else {
      ctx.fillStyle = '#1f2937'
      ctx.fillRect(0, 0, w, h)
    }
    // 2) 围栏/检测框/轨迹覆盖层
    if (overlay && overlay.width) ctx.drawImage(overlay, 0, 0, w, h)
    // 3) 夜间模式提示（快照上保留取证语义）
    if (props.nightMode) {
      ctx.fillStyle = 'rgba(12,10,35,0.35)'
      ctx.fillRect(0, 0, w, h)
    }
    // 4) 顶部水印条
    const stamp = `薪守疆隅 · 电子围栏告警抓拍  ${new Date().toLocaleString('zh-CN', { hour12: false })}${props.nightMode ? ' ｜夜间闭园巡查' : ''}`
    ctx.font = 'bold 22px "Microsoft YaHei", sans-serif'
    const tw = ctx.measureText(stamp).width
    ctx.fillStyle = 'rgba(196,30,58,0.92)'
    ctx.fillRect(0, 0, tw + 36, 40)
    ctx.fillStyle = '#FFFFFF'
    ctx.fillText(stamp, 18, 28)
    return out.toDataURL('image/jpeg', 0.72)
  } catch {
    return null // 抓拍失败（极端兼容情况）不阻断告警主流程
  }
}
defineExpose({ videoRef, captureSnapshot })

/* 【修复点3】绘制态单一事实源：只有 isDrawingFence === true 时，画布鼠标事件才生效 */
const isDrawingFence = computed(() => props.drawing?.active === true)

/* ---------- 围栏图层样式配置（修复点6：三层配色保持不变） ---------- */
const LEVEL_STYLE = {
  warn: { color: '#F59E0B', name: '警戒区' },
  danger: { color: '#EA580C', name: '危险禁区' },
  core: { color: '#DC2626', name: '核心遗存保护区' },
}

// 围栏图例（左上角提示）
const legend = [
  { name: '警戒区', color: '#F59E0B' },
  { name: '危险禁区', color: '#EA580C' },
  { name: '核心遗存保护区', color: '#DC2626' },
]

// 悬浮工具条：分级告警演示按钮配置
const demoLevels = [
  { key: 'warn', name: '警戒', color: '#F59E0B', icon: 'fa-person-walking' },
  { key: 'danger', name: '危险', color: '#EA580C', icon: 'fa-triangle-exclamation' },
  { key: 'core', name: '核心', color: '#DC2626', icon: 'fa-radiation' },
]

// 【修复点4】点击首点多少 CSS 像素范围内视为"点击首点闭合"
const CLOSE_HIT_PX = 18

/* =====================================================================
 * 【修复点2】鼠标坐标 → 视频帧归一化坐标(0~1)
 * 1) 沿 offsetParent 链累计 offsetLeft/offsetTop，得到 canvas 相对页面的位置；
 *    叠加 window.scrollX/scrollY 兼容页面滚动（clientX 是视口坐标）
 * 2) canvas 与 video 同为 object-fit:cover 填充，再按 cover 裁切比例逆推，
 *    消除因等比缩放/居中裁切造成的落点偏移
 * ===================================================================== */
function getCanvasPageOffset() {
  let x = 0
  let y = 0
  let node = canvasRef.value
  // 累计定位祖先链：等价于 canvas.offsetLeft/offsetTop 的完整页面偏移
  while (node) {
    x += node.offsetLeft
    y += node.offsetTop
    node = node.offsetParent
  }
  return { x, y }
}

function toVideoCoords(e) {
  const video = videoRef.value
  const canvas = canvasRef.value
  if (!video || !canvas || !video.videoWidth) return null
  const rect = canvas.getBoundingClientRect()
  const { x: pageX, y: pageY } = getCanvasPageOffset()
  // 鼠标相对 canvas CSS 盒左上角的坐标（含滚动量补偿）
  const cssX = e.clientX + window.scrollX - pageX
  const cssY = e.clientY + window.scrollY - pageY
  const vw = video.videoWidth
  const vh = video.videoHeight
  // cover 缩放系数与居中裁切偏移
  const scale = Math.max(rect.width / vw, rect.height / vh)
  const offX = (rect.width - vw * scale) / 2
  const offY = (rect.height - vh * scale) / 2
  // 逆变换回视频帧像素，再归一化并夹取到 [0,1]
  const x = (cssX - offX) / scale
  const y = (cssY - offY) / scale
  return {
    x: Math.min(Math.max(x / vw, 0), 1),
    y: Math.min(Math.max(y / vh, 0), 1),
  }
}

/* ---------- 【修复点3/4】画布鼠标事件：全部以 isDrawingFence 为前置守卫 ---------- */

/** 左键单击：新增顶点；若已有 ≥3 点且点击位置靠近首点，则自动闭合 */
function onClick(e) {
  if (!isDrawingFence.value) return // 非绘制态不响应，避免误操作
  const p = toVideoCoords(e)
  if (!p) return
  const pts = props.drawing.points
  // 【修复点4】点击靠近第一个顶点 → 直接闭合（至少 3 个顶点）
  if (pts.length >= 3 && isNearFirstPoint(p)) {
    emit('draw-complete')
    return
  }
  emit('point-add', p)
  // 【修复点5】顶点写入后立即同步重绘一次（父级传入的是同一个 reactive 对象，变更立即可见），
  // 不必等待下一帧，保证"点击即出点、即连线"
  drawFrame()
}

/** 双击闭合（浏览器在 dblclick 前会补发两次 click，重复点由 useFenceDraw.dedupePoints 去重） */
function onDblclick() {
  if (!isDrawingFence.value) return
  emit('draw-complete')
}

/** 右键：清空本次正在绘制的顶点并取消绘制（仅绘制态拦截浏览器默认菜单） */
function onContextmenu(e) {
  if (!isDrawingFence.value) return
  e.preventDefault() // 阻止右键菜单弹出
  emit('draw-cancel')
}

/** 鼠标移动：仅绘制态更新橡皮筋预览终点 */
function onMousemove(e) {
  if (!isDrawingFence.value) return
  const p = toVideoCoords(e)
  if (p) {
    emit('cursor-move', p)
    // 橡皮筋需要跟随光标，移动即重绘一帧，手感更跟手
    drawFrame()
  }
}

/** 判断归一化点是否落在首点的闭合热区内（按 CSS 像素距离判定） */
function isNearFirstPoint(p) {
  const first = props.drawing.points[0]
  const rect = canvasRef.value?.getBoundingClientRect()
  if (!first || !rect) return false
  // 归一化距离换算回画布 CSS 像素距离（x/y 方向缩放不同，分别换算）
  const dx = (p.x - first.x) * rect.width
  const dy = (p.y - first.y) * rect.height
  return Math.hypot(dx, dy) <= CLOSE_HIT_PX
}

/* ---------- 【修复点5】渲染：drawFrame 单次绘制 + rAF 持续循环 ---------- */
let rafId = null

function drawFrame() {
  const video = videoRef.value
  const canvas = canvasRef.value
  if (!canvas) return
  const ctx = canvas.getContext('2d')
  const vw = video?.videoWidth || 0
  const vh = video?.videoHeight || 0
  // canvas 内部分辨率对齐视频帧（CSS object-fit:cover 与视频完全重叠）
  if (vw && vh && (canvas.width !== vw || canvas.height !== vh)) {
    canvas.width = vw
    canvas.height = vh
  }
  ctx.clearRect(0, 0, canvas.width, canvas.height)
  if (props.cameraOn && vw && vh) {
    drawFences(ctx, vw, vh)
    drawStudy(ctx, vw, vh) // 【阶段4】研学队伍质心轨迹（在检测框下层）
    drawDetections(ctx)
    drawDrawing(ctx, vw, vh)
  }
}

// 持续渲染循环：支撑已存围栏呼吸高亮、光标橡皮筋、检测框刷新等动态效果
function renderLoop() {
  drawFrame()
  rafId = requestAnimationFrame(renderLoop)
}
onMounted(() => (rafId = requestAnimationFrame(renderLoop)))
onUnmounted(() => cancelAnimationFrame(rafId))

/** 绘制已保存的三层围栏多边形（告警等级命中时呼吸脉冲高亮） */
function drawFences(ctx, vw, vh) {
  const t = Date.now()
  for (const key of Object.keys(LEVEL_STYLE)) {
    const { color, name } = LEVEL_STYLE[key]
    for (const poly of props.fences[key]) {
      if (poly.length < 3) continue
      // 当前告警等级命中该层时：填充透明度随时间呼吸，强化声光效果
      const alarmHit = props.alarmLevel === key
      const alpha = alarmHit ? 0.22 + 0.18 * Math.abs(Math.sin(t / 180)) : 0.15
      ctx.beginPath()
      poly.forEach((p, i) =>
        i ? ctx.lineTo(p.x * vw, p.y * vh) : ctx.moveTo(p.x * vw, p.y * vh),
      )
      ctx.closePath()
      ctx.fillStyle = hexToRgba(color, alpha)
      ctx.fill()
      ctx.setLineDash([12, 7])
      ctx.lineWidth = alarmHit ? 4 : 2
      ctx.strokeStyle = color
      ctx.stroke()
      ctx.setLineDash([])
      // 顶点标记
      ctx.fillStyle = '#FFFFFF'
      ctx.strokeStyle = color
      ctx.lineWidth = 2
      for (const p of poly) {
        ctx.beginPath()
        ctx.arc(p.x * vw, p.y * vh, 4, 0, Math.PI * 2)
        ctx.fill()
        ctx.stroke()
      }
      // 围栏名称标签（首顶点处）
      const lx = poly[0].x * vw
      const ly = poly[0].y * vh
      ctx.font = 'bold 16px "Microsoft YaHei", sans-serif'
      const tw = ctx.measureText(name).width
      ctx.fillStyle = color
      ctx.fillRect(lx, ly - 24, tw + 14, 22)
      ctx.fillStyle = '#FFFFFF'
      ctx.fillText(name, lx + 7, ly - 7)
    }
  }
}

/** 【阶段4】绘制研学监管图层：队伍质心移动轨迹 + 质心标记 + 脱队连线 */
function drawStudy(ctx, vw, vh) {
  if (!props.studyActive) return
  const info = props.studyInfo
  const GOLD = '#FBBF24'

  // 1) 质心轨迹：越旧的轨迹点越淡，呈现拖尾效果
  const trail = info.trail || []
  if (trail.length > 1) {
    for (let i = 1; i < trail.length; i++) {
      const alpha = 0.15 + 0.55 * (i / trail.length) // 新点亮、旧点淡
      ctx.beginPath()
      ctx.moveTo(trail[i - 1].x * vw, trail[i - 1].y * vh)
      ctx.lineTo(trail[i].x * vw, trail[i].y * vh)
      ctx.strokeStyle = hexToRgba('#F59E0B', alpha)
      ctx.lineWidth = 2.5
      ctx.stroke()
    }
    // 轨迹采样小圆点
    for (let i = 0; i < trail.length; i += 4) {
      ctx.beginPath()
      ctx.arc(trail[i].x * vw, trail[i].y * vh, 2.5, 0, Math.PI * 2)
      ctx.fillStyle = hexToRgba(GOLD, 0.5)
      ctx.fill()
    }
  }

  // 2) 脱队人员 → 队伍质心的橙色虚线（直观呈现"离群"距离）
  if (info.centroid && Array.isArray(info.strayBoxes) && info.strayBoxes.length) {
    ctx.setLineDash([10, 6])
    ctx.strokeStyle = 'rgba(234,88,12,0.75)'
    ctx.lineWidth = 2
    for (const bbox of info.strayBoxes) {
      const [bx, by, bw] = bbox
      const fx = bx + bw / 2 // 脱队者脚底点（视频像素坐标）
      const fy = by + bbox[3]
      ctx.beginPath()
      ctx.moveTo(fx, fy)
      ctx.lineTo(info.centroid.x * vw, info.centroid.y * vh)
      ctx.stroke()
    }
    ctx.setLineDash([])
  }

  // 3) 队伍质心标记：金色脉冲圆 + 十字 + 标签
  if (info.centroid) {
    const cx = info.centroid.x * vw
    const cy = info.centroid.y * vh
    const pulse = 10 + 5 * Math.abs(Math.sin(Date.now() / 220))
    ctx.beginPath()
    ctx.arc(cx, cy, 8 + pulse, 0, Math.PI * 2)
    ctx.strokeStyle = hexToRgba(GOLD, 0.45)
    ctx.lineWidth = 2
    ctx.stroke()
    ctx.beginPath()
    ctx.arc(cx, cy, 9, 0, Math.PI * 2)
    ctx.fillStyle = GOLD
    ctx.fill()
    ctx.strokeStyle = '#FFFFFF'
    ctx.lineWidth = 2.5
    ctx.stroke()
    // 十字射线
    ctx.strokeStyle = GOLD
    ctx.lineWidth = 1.5
    ctx.beginPath()
    ctx.moveTo(cx - 16, cy); ctx.lineTo(cx + 16, cy)
    ctx.moveTo(cx, cy - 16); ctx.lineTo(cx, cy + 16)
    ctx.stroke()
    // 标签
    ctx.font = 'bold 15px "Microsoft YaHei", sans-serif'
    const label = '队伍中心'
    const tw = ctx.measureText(label).width
    ctx.fillStyle = 'rgba(180,83,9,0.92)'
    ctx.fillRect(cx + 12, cy - 26, tw + 12, 21)
    ctx.fillStyle = '#FFFFFF'
    ctx.fillText(label, cx + 18, cy - 11)
  }
}

/** 绘制检测结果：人员红框 / 干扰目标灰虚线框（干扰过滤开启时隐藏）；研学脱队人员橙色高亮圈 */
function drawDetections(ctx) {
  let filteredCount = 0
  for (const d of props.detections) {
    const isPerson = d.class === 'person'
    if (!isPerson) {
      filteredCount++
      if (props.interferenceFilter) continue // 干扰过滤：直接隐藏
    }
    const [x, y, w, h] = d.bbox
    ctx.lineWidth = 2
    // 【阶段4】研学模式：判断该人员是否被监管模块标记为脱队（同帧 bbox 引用比对）
    const isStray =
      isPerson &&
      props.studyActive &&
      Array.isArray(props.studyInfo.strayBoxes) &&
      props.studyInfo.strayBoxes.includes(d.bbox)
    if (isPerson) {
      ctx.strokeStyle = isStray ? '#EA580C' : '#DC2626'
      ctx.fillStyle = isStray ? 'rgba(234,88,12,0.9)' : 'rgba(220,38,38,0.88)'
      ctx.lineWidth = isStray ? 3.5 : 2
    } else {
      ctx.strokeStyle = '#9CA3AF'
      ctx.fillStyle = 'rgba(75,85,99,0.85)'
      ctx.setLineDash([6, 4])
    }
    ctx.strokeRect(x, y, w, h)
    ctx.setLineDash([])
    // 脱队人员：框外再套一圈呼吸橙环，强化提醒
    if (isStray) {
      const pad = 6 + 3 * Math.abs(Math.sin(Date.now() / 180))
      ctx.strokeStyle = 'rgba(234,88,12,0.6)'
      ctx.lineWidth = 2
      ctx.strokeRect(x - pad, y - pad, w + pad * 2, h + pad * 2)
    }
    // 标签：脱队 / 人员 置信度 / 干扰目标·类别
    const label = !isPerson
      ? `干扰目标·${d.class} ${Math.round(d.score * 100)}%`
      : isStray
        ? `脱队人员 ${Math.round(d.score * 100)}%`
        : `人员 ${Math.round(d.score * 100)}%`
    ctx.font = 'bold 14px "Microsoft YaHei", sans-serif'
    const tw = ctx.measureText(label).width
    ctx.fillRect(x, y - 20, tw + 10, 19)
    ctx.fillStyle = '#FFFFFF'
    ctx.fillText(label, x + 5, y - 5)
  }
  // 干扰过滤生效提示（右上角徽标下方）
  if (props.interferenceFilter && filteredCount > 0) {
    ctx.font = 'bold 14px "Microsoft YaHei", sans-serif'
    const text = `干扰过滤已开启：已过滤 ${filteredCount} 个干扰目标`
    const tw = ctx.measureText(text).width
    ctx.fillStyle = 'rgba(245,158,11,0.9)'
    ctx.fillRect(ctx.canvas.width - tw - 22, 44, tw + 14, 22)
    ctx.fillStyle = '#FFFFFF'
    ctx.fillText(text, ctx.canvas.width - tw - 15, 60)
  }
}

/** 绘制进行中的围栏：首点闭合热区 + 已落点 + 连线 + 橡皮筋预览 + 操作提示 */
function drawDrawing(ctx, vw, vh) {
  const d = props.drawing
  if (!d.active) return
  const { color } = LEVEL_STYLE[d.level]
  const pts = d.points

  // 【修复点4】首点闭合热区：≥3 点时在首顶点绘制呼吸圆环，提示"点此闭合"
  if (pts.length >= 3) {
    const f = pts[0]
    const pulse = 10 + 4 * Math.abs(Math.sin(Date.now() / 200))
    ctx.beginPath()
    ctx.arc(f.x * vw, f.y * vh, 6 + pulse, 0, Math.PI * 2)
    ctx.strokeStyle = hexToRgba(color, 0.55)
    ctx.lineWidth = 1.5
    ctx.stroke()
  }

  // 已落点连线（≥3点时闭合虚线预览）
  if (pts.length) {
    ctx.beginPath()
    pts.forEach((p, i) => (i ? ctx.lineTo(p.x * vw, p.y * vh) : ctx.moveTo(p.x * vw, p.y * vh)))
    if (pts.length >= 3) ctx.closePath()
    ctx.strokeStyle = color
    ctx.lineWidth = 2.5
    ctx.stroke()
  }
  // 橡皮筋：最后一点 → 光标
  if (pts.length && d.cursor) {
    ctx.beginPath()
    ctx.moveTo(pts[pts.length - 1].x * vw, pts[pts.length - 1].y * vh)
    ctx.lineTo(d.cursor.x * vw, d.cursor.y * vh)
    ctx.setLineDash([8, 6])
    ctx.strokeStyle = hexToRgba(color, 0.7)
    ctx.lineWidth = 2
    ctx.stroke()
    ctx.setLineDash([])
  }
  // 落点小圆点（首点用白色实心高亮，区别于其余顶点）
  pts.forEach((p, i) => {
    ctx.beginPath()
    ctx.arc(p.x * vw, p.y * vh, i === 0 ? 6 : 5, 0, Math.PI * 2)
    ctx.fillStyle = i === 0 ? '#FFFFFF' : color
    ctx.fill()
    ctx.strokeStyle = i === 0 ? color : '#FFFFFF'
    ctx.lineWidth = 2
    ctx.stroke()
  })
  // 光标十字 + 提示文字
  if (d.cursor) {
    const cx = d.cursor.x * vw
    const cy = d.cursor.y * vh
    ctx.strokeStyle = hexToRgba(color, 0.8)
    ctx.lineWidth = 1.5
    ctx.beginPath()
    ctx.moveTo(cx - 12, cy)
    ctx.lineTo(cx + 12, cy)
    ctx.moveTo(cx, cy - 12)
    ctx.lineTo(cx, cy + 12)
    ctx.stroke()
    const hint =
      pts.length >= 3 ? `已记录 ${pts.length} 个点，双击或点击首点闭合` : `已记录 ${pts.length} 个点，至少 3 个点闭合`
    ctx.font = 'bold 15px "Microsoft YaHei", sans-serif'
    const tw = ctx.measureText(hint).width
    ctx.fillStyle = 'rgba(0,0,0,0.65)'
    ctx.fillRect(cx + 16, cy + 12, tw + 14, 24)
    ctx.fillStyle = color
    ctx.fillText(hint, cx + 23, cy + 29)
  }
}

/** 十六进制颜色 → rgba 字符串 */
function hexToRgba(hex, alpha) {
  const r = parseInt(hex.slice(1, 3), 16)
  const g = parseInt(hex.slice(3, 5), 16)
  const b = parseInt(hex.slice(5, 7), 16)
  return `rgba(${r},${g},${b},${alpha})`
}
</script>

<template>
  <!-- 视频预览容器：告警时边框红色光晕脉冲（danger/core 级声光效果） -->
  <div
    class="relative w-full h-full bg-gray-900 rounded-xl overflow-hidden
           shadow-xl ring-1 ring-china-red/30"
    :class="alarmLevel === 'danger' || alarmLevel === 'core' ? 'animate-alarm-flash' : ''"
  >
    <!--
      【修复点1】摄像头实时画面：pointer-events-none + select-none，
      保证 video 绝不拦截鼠标，点击事件全部交给上层 canvas
    -->
    <video
      ref="videoRef"
      class="absolute inset-0 w-full h-full object-cover pointer-events-none select-none"
      autoplay
      playsinline
      muted
    ></video>

    <!--
      【修复点1】Canvas 覆盖层：明确 pointer-events-auto，位于 video 之上接收全部鼠标事件；
      【修复点3】仅绘制态显示十字光标
    -->
    <canvas
      ref="canvasRef"
      class="absolute inset-0 w-full h-full object-cover pointer-events-auto"
      :class="isDrawingFence ? 'cursor-crosshair' : 'cursor-default'"
      @click="onClick"
      @dblclick="onDblclick"
      @contextmenu="onContextmenu"
      @mousemove="onMousemove"
    ></canvas>

    <!--
      【阶段4】夜间闭园巡查滤镜：深蓝黑半透明遮罩营造夜视氛围（纯展示 pointer-events-none）
      置于 canvas 之上、信息角标之下，不影响鼠标落点
    -->
    <div
      v-if="nightMode"
      class="absolute inset-0 pointer-events-none
             bg-gradient-to-b from-indigo-950/55 via-blue-950/35 to-indigo-950/60"
    ></div>

    <!-- 待机占位覆盖层（摄像头未开启时显示项目主视觉；纯展示 pointer-events:none 透传） -->
    <div
      v-if="!cameraOn"
      class="absolute inset-0 flex flex-col items-center justify-center gap-4
             bg-gradient-to-b from-gray-900 via-[#3d0a14] to-gray-900 pointer-events-none"
    >
      <img
        src="../assets/red.jpg"
        alt="薪守疆隅主视觉"
        class="w-44 h-44 object-cover rounded-full opacity-95
               ring-4 ring-amber-400/40
               drop-shadow-[0_0_28px_rgba(245,158,11,0.35)]"
      />
      <p class="text-white/90 font-bold tracking-[0.5em] text-xl pl-2">薪 守 疆 隅</p>
      <p class="text-amber-200/70 text-sm tracking-widest">
        摄像头待机中 · 请在右侧控制面板开启摄像头
      </p>
    </div>

    <!-- 错误提示条（摄像头权限 / 模型加载失败；纯展示 pointer-events-none） -->
    <div
      v-if="errorMsg"
      class="absolute top-14 left-1/2 -translate-x-1/2 max-w-[80%] px-4 py-2 rounded-lg
             bg-red-600/90 text-white text-xs shadow-lg pointer-events-none"
    >
      <i class="fa-solid fa-triangle-exclamation mr-1"></i>{{ errorMsg }}
    </div>

    <!-- 左上角：三层围栏图例（【修复点1】纯展示层 pointer-events-none，避免遮挡画布落点） -->
    <div
      class="absolute top-3 left-3 flex flex-col gap-1.5 px-3 py-2 rounded-lg
             bg-black/45 backdrop-blur text-xs text-white/90 pointer-events-none"
    >
      <span class="font-bold text-amber-300 mb-0.5">
        <i class="fa-solid fa-shield-halved mr-1"></i>虚拟电子围栏图例
      </span>
      <span v-for="item in legend" :key="item.name" class="flex items-center gap-2">
        <span class="w-3 h-3 rounded-sm" :style="{ backgroundColor: item.color }"></span>
        {{ item.name }}
      </span>
    </div>

    <!-- 右上角：AI 本地推理标识（纯展示 pointer-events-none） -->
    <div
      class="absolute top-3 right-3 px-3 py-1.5 rounded-lg bg-black/45 backdrop-blur
             text-[11px] text-emerald-300 tracking-wider pointer-events-none"
    >
      <i class="fa-solid fa-lock mr-1"></i>AI 边缘推理 · 数据不出浏览器
    </div>

    <!-- 【阶段4】夜间闭园巡查角标（左上角图例下方） -->
    <div
      v-if="nightMode"
      class="absolute top-[104px] left-3 flex items-center gap-2 px-3 py-1.5 rounded-lg
             bg-indigo-950/70 backdrop-blur text-xs text-indigo-200 border border-indigo-400/40
             pointer-events-none"
    >
      <i class="fa-solid fa-moon text-indigo-300"></i>
      <span class="font-bold tracking-wider">夜间闭园巡查</span>
      <span class="font-mono text-indigo-100">{{ clockText }}</span>
      <span class="text-[10px] text-indigo-300/80">高灵敏度 · 出现人员即告警</span>
    </div>

    <!-- 【阶段4】研学监管角标（左上角图例下方，白天/夜间互斥占位） -->
    <div
      v-if="studyActive"
      class="absolute top-[104px] left-3 flex items-center gap-2 px-3 py-1.5 rounded-lg
             bg-amber-950/60 backdrop-blur text-xs text-amber-200 border border-amber-400/40
             pointer-events-none"
      :class="nightMode ? 'top-[136px]' : ''"
    >
      <i class="fa-solid fa-users text-amber-300"></i>
      <span class="font-bold tracking-wider">研学队伍监管中</span>
      <span class="text-[10px] text-amber-300/80">防走失 · 防越界</span>
    </div>

    <!--
      悬浮快捷工具条：摄像头开关 + 分级告警演示（答辩演示无需真人走动）
      【修复点1】该层含真实按钮，保持 pointer-events 默认可点击；
                它只占据底部居中一小块区域，不影响其余画布区域落点
    -->
    <div
      class="absolute bottom-11 left-1/2 -translate-x-1/2 flex items-center gap-2
             px-3 py-2 rounded-full bg-black/60 backdrop-blur shadow-lg"
    >
      <button
        class="px-3 py-1.5 rounded-full text-xs font-bold text-white transition"
        :class="cameraOn ? 'bg-gray-600 hover:bg-gray-500' : 'bg-china-red hover:bg-[#a3122c]'"
        @click="emit('quick-camera')"
      >
        <i :class="['fa-solid mr-1', cameraOn ? 'fa-stop' : 'fa-play']"></i>
        {{ cameraOn ? '关闭摄像头' : '开启摄像头' }}
      </button>
      <span class="w-px h-4 bg-white/25"></span>
      <span class="text-[11px] text-white/60 tracking-wider">告警演示</span>
      <button
        v-for="lv in demoLevels"
        :key="lv.key"
        class="px-2.5 py-1.5 rounded-full text-xs font-bold border transition"
        :class="alarmLevel === lv.key
          ? 'text-white border-white/70 scale-105 shadow-lg'
          : 'bg-white/10 text-white/85 border-white/20 hover:bg-white/20'"
        :style="alarmLevel === lv.key ? { backgroundColor: lv.color } : {}"
        :title="alarmLevel === lv.key ? '再次点击解除演示' : `模拟触发${lv.name}告警`"
        @click="emit('demo-alarm', lv.key)"
      >
        <i :class="['fa-solid mr-1', lv.icon]"></i>{{ lv.name }}
      </button>
    </div>

    <!-- 底部操作提示条（【修复点1】纯展示 pointer-events-none；绘制中切换为绘制提示） -->
    <div
      class="absolute bottom-0 inset-x-0 px-4 py-2 flex items-center gap-5
             bg-black/55 backdrop-blur text-xs text-white/85 pointer-events-none"
    >
      <template v-if="!isDrawingFence">
        <span><i class="fa-solid fa-video text-amber-300"></i> ① 开启摄像头</span>
        <span><i class="fa-solid fa-draw-polygon text-amber-300"></i> ② 选择围栏等级，点击"新增围栏"后点击画面绘制多边形</span>
        <span><i class="fa-solid fa-bell text-amber-300"></i> ③ 人员越界自动分级告警</span>
      </template>
      <template v-else>
        <span class="text-amber-300 font-bold">
          <i class="fa-solid fa-pen-ruler mr-1"></i>围栏绘制中
        </span>
        <span>左键点击落点</span>
        <span>双击 / 点击首点附近闭合（至少 3 点）</span>
        <span>右键取消</span>
      </template>
    </div>
  </div>
</template>
