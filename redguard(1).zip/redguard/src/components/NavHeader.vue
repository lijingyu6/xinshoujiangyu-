<script setup>
/**
 * NavHeader.vue —— 顶部全局导航栏组件
 * 红色底色 + 白色标题【薪守疆隅｜红色遗址智能电子围栏预警系统】
 * 右侧实时系统状态标签：待机 / 模型加载中 / 监测中 / 告警闪烁
 */
import { computed } from 'vue'

const props = defineProps({
  // 系统状态：standby | loading | monitoring | alarm
  status: { type: String, default: 'standby' },
})

// 状态标签配置映射（圆点颜色 / 徽标配色）
const STATUS_MAP = {
  standby: {
    label: '待机',
    dot: 'bg-gray-300',
    badge: 'bg-white/15 text-white border-white/30',
  },
  loading: {
    label: '模型加载中',
    dot: 'bg-amber-300 animate-status-pulse',
    badge: 'bg-amber-400/20 text-amber-100 border-amber-300/40',
  },
  monitoring: {
    label: '监测中',
    dot: 'bg-emerald-300 animate-status-pulse',
    badge: 'bg-emerald-400/20 text-emerald-100 border-emerald-300/40',
  },
  alarm: {
    label: '告警中',
    dot: 'bg-white animate-status-pulse',
    badge: 'bg-red-600/60 text-white border-red-200/70 animate-alarm-flash',
  },
}
const statusInfo = computed(() => STATUS_MAP[props.status] || STATUS_MAP.standby)
</script>

<template>
  <header
    class="relative h-16 shrink-0 z-10 text-white shadow-lg
           bg-gradient-to-r from-[#9e1129] via-china-red to-[#9e1129]"
  >
    <!-- 金色描边装饰线：庄重华丽风格点缀 -->
    <div
      class="absolute bottom-0 inset-x-0 h-[3px]
             bg-gradient-to-r from-amber-300 via-amber-500 to-amber-300"
    ></div>

    <div class="h-full px-5 flex items-center justify-between">
      <!-- 左侧：徽标 + 系统标题 -->
      <div class="flex items-center gap-3">
        <img
          src="../assets/red.jpg"
          alt="薪守疆隅徽标"
          class="w-11 h-11 rounded-full bg-white object-cover p-0.5
                 ring-2 ring-amber-300/80 shadow"
        />
        <div>
          <h1 class="text-xl font-bold tracking-widest leading-tight">
            <i class="fa-solid fa-star text-amber-300 mr-2 text-base"></i>薪守疆隅
            <span class="mx-2 text-white/50 font-normal">｜</span>
            <span class="text-base font-semibold tracking-wide">
              红色遗址智能电子围栏预警系统
            </span>
          </h1>
          <p class="text-[11px] text-amber-100/80 tracking-[0.28em] mt-0.5">
            守护红色遗址 · 传承红色基因
          </p>
        </div>
      </div>

      <!-- 右侧：实时系统状态标签 -->
      <div
        :class="[
          'flex items-center gap-2 px-4 py-1.5 rounded-full border text-sm font-semibold shadow',
          statusInfo.badge,
        ]"
      >
        <span :class="['w-2.5 h-2.5 rounded-full', statusInfo.dot]"></span>
        <i class="fa-solid fa-satellite-dish text-xs"></i>
        系统状态：{{ statusInfo.label }}
      </div>
    </div>
  </header>
</template>
