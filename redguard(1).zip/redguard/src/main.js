import { createApp } from 'vue'
// FontAwesome 图标库（npm 本地依赖引入，答辩现场不依赖图标 CDN）
import '@fortawesome/fontawesome-free/css/all.min.css'
// Tailwind 指令 + 全局主题动画
import './style.css'
import App from './App.vue'

createApp(App).mount('#app')
