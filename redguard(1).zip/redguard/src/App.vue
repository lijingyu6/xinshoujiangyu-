<script setup>
/**
 * App.vue —— 主页面（业务编排中枢 · 阶段4 完整版）
 * 组合式函数：摄像头 / AI人体检测 / 围栏绘制 / 分级告警 / 研学监管 / 24h巡查
 * 每帧统一汇总【围栏越界 + 研学事件 + 夜间入侵】三类信号，
 * 取最高告警等级一次性驱动声光；关键告警同步抓拍快照并写入持久化日志
 */
import { ref, computed, watch, onMounted, onUnmounted } from 'vue'
import NavHeader from './components/NavHeader.vue'
import VideoCanvas from './components/VideoCanvas.vue'
import ControlPanel from './components/ControlPanel.vue'
import AlarmLogPanel from './components/AlarmLogPanel.vue'

import { useCamera } from './composables/useCamera'
import { usePersonDetect } from './composables/usePersonDetect'
import { useFenceDraw } from './composables/useFenceDraw'
import { useAlarm } from './composables/useAlarm'
import { useStudyGuard } from './composables/useStudyGuard'
import { usePatrol } from './composables/usePatrol'

/* ---------- 组合式函数实例化 ---------- */
const vcRef = ref(null)
const getVideo = () => vcRef.value?.videoRef || null

const { cameraOn, cameraError, openCamera, closeCamera } = useCamera(getVideo)
const { modelLoading, modelReady, modelError, detections, loadModel, startDetect, stopDetect } =
  usePersonDetect()
const {
  fences, drawing, fenceCounts, startDraw, addPoint, moveCursor, completeDraw,
  cancelDraw, clearFences, evaluatePoint, saveFences,
} = useFenceDraw()
const { alarmLevel, logs, speak, setLevel, addLog, clearLogs, exportLogs } = useAlarm()
const { state: studyState, evaluate: studyEvaluate, reset: studyReset } = useStudyGuard()
const {
  useRealTime, simMinutes, isNight, periodLabel, clockText, cursorPercent, dayRange,
  setSimMinutes, fastForward, followRealTime,
} = usePatrol()

/* ---------- 面板状态 ---------- */
const activeLevel = ref('warn')
const interferenceFilter = ref(true)
const studyMode = ref(false)
const teamTotal = ref(30)
const activeMode = ref('normal')
const toast = ref('')
let toastTimer = null

/* ---------- 派生数据 ---------- */
// person 人体目标（预警判定对象）
const persons = computed(() => detections.value.filter((d) => d.class === 'person'))

// 研学画布绘制数据：质心 / 轨迹 / 脱队人员 bbox 引用
const studyInfo = computed(() => ({
  centroid: studyState.centroid,
  trail: studyState.trail,
  strayBoxes: persons.value
    .map((d) => d.bbox)
    .filter((_, i) => studyState.strayIndices.includes(i)),
}))

// 系统状态机：告警 > 模型加载中 > 监测中 > 待机
const systemStatus = computed(() => {
  if (alarmLevel.value !== 'none') return 'alarm'
  if (modelLoading.value) return 'loading'
  if (cameraOn.value) return 'monitoring'
  return 'standby'
})
const combinedError = computed(() => cameraError.value || modelError.value)

// 无人值守夜间模式（画面出现人员即入侵）
const nightPatrol = computed(() => activeMode.value === 'unattended' && isNight.value)

/* ---------- 生命周期 ---------- */
onMounted(() => loadModel())
onUnmounted(() => {
  stopDetect()
  closeCamera()
})

/* ---------- 摄像头控制 ---------- */
async function handleOpenCamera() {
  const ok = await openCamera()
  if (ok) {
    startDetect(getVideo)
    showToast('摄像头已开启，AI 人体检测运行中')
  }
}
function handleCloseCamera() {
  stopDetect()
  closeCamera()
  setLevel('none')
  showToast('摄像头已关闭')
}

/* ---------- 围栏绘制 ---------- */
const LEVEL_NAME = { warn: '警戒区', danger: '危险禁区', core: '核心遗存保护区' }

function handleStartDraw() {
  if (!cameraOn.value) return
  startDraw(activeLevel.value)
  showToast(`开始绘制【${LEVEL_NAME[activeLevel.value]}】，在画面上点击落点`)
}
function handlePointAdd(p) {
  if (drawing.active) addPoint(p)
}
function handleDrawComplete() {
  if (!drawing.active) return
  const lv = completeDraw()
  if (lv) {
    const n = fences[lv][fences[lv].length - 1].length
    showToast(`【${LEVEL_NAME[lv]}】围栏闭合成功（${n} 个顶点），请点击"保存围栏"持久化`)
  } else {
    showToast('围栏未闭合（至少需要 3 个点），已取消')
  }
}
function handleCancelDraw() {
  if (!drawing.active) return
  cancelDraw()
  showToast('已取消绘制')
}
function handleSaveFences() {
  saveFences()
  showToast('围栏配置已保存至浏览器本地存储，刷新页面不丢失')
}
function handleClearFences() {
  cancelDraw()
  clearFences()
  showToast('已清空全部围栏')
}

/* ---------- 告警工具 ---------- */
const RANK = { none: 0, warn: 1, danger: 2, core: 3 }
function maxLevel(a, b) {
  return RANK[a] >= RANK[b] ? a : b
}
/** 抓拍当前画面快照（摄像头未开时返回合成占位图） */
function takeSnapshot() {
  return vcRef.value?.captureSnapshot?.() || null
}

// 围栏各级别语音/日志冷却
let lastWarnSpeak = 0
let lastCoreSpeak = 0
let lastCoreLog = 0
let lastDangerLog = 0
const WARN_TEXTS = [
  '游客朋友您好，您已进入遗址警戒区域，请退回参观步道。守护红色遗址，传承红色基因，感谢您的配合。',
  '您好，前方为遗址警戒范围，为了保护珍贵红色遗存，请您退到参观通道，谢谢理解与支持。',
  '温馨提示：您已靠近遗址保护区边界，请勿跨越警戒线，让我们共同守护红色记忆。',
]

/**
 * 围栏越界分级处理：只负责语音劝阻/日志冷却（不再直接 setLevel，等级由每帧汇总统一驱动）
 * @returns 围栏命中等级 'none'|'warn'|'danger'|'core'
 */
function handleFenceLevel(level) {
  const now = Date.now()
  if (level === 'warn' && now - lastWarnSpeak > 12000) {
    speak(WARN_TEXTS[Math.floor(Math.random() * WARN_TEXTS.length)])
    lastWarnSpeak = now
  }
  if (level === 'danger' && now - lastDangerLog > 15000) {
    addLog('danger', '危险区域接近', '检测到人员踏入危险禁区，已触发声光闪烁告警', takeSnapshot())
    lastDangerLog = now
  }
  if (level === 'core') {
    if (now - lastCoreSpeak > 9000) {
      speak('警告！您已闯入核心遗存保护区，请立即撤离！')
      lastCoreSpeak = now
    }
    if (now - lastCoreLog > 8000) {
      addLog('critical', '越界闯入', '检测到人员闯入核心遗存保护区，已触发强声光告警并记录', takeSnapshot())
      lastCoreLog = now
    }
  }
  return level
}

/* ---------- 夜间非法入侵（无人值守模式） ---------- */
let lastIntruderLog = 0
function checkNightIntruder(personList) {
  if (!nightPatrol.value || personList.length === 0) return 'none'
  const now = Date.now()
  if (now - lastIntruderLog > 12000) {
    lastIntruderLog = now
    speak('警告！闭园时段检测到非法入侵人员，安防系统已启动强声光告警！')
    addLog(
      'critical',
      '夜间非法入侵',
      `闭园巡查时段画面中检测到 ${personList.length} 名人员，判定为非法入侵，已抓拍取证`,
      takeSnapshot(),
      { night: true },
    )
  }
  return 'core'
}

/* ---------- 手动演示告警（悬浮工具条，8 秒内不被实时评估覆盖） ---------- */
let manualLevel = 'none'
let manualTimer = null
function handleDemoAlarm(level) {
  if (manualLevel === level) {
    manualLevel = 'none'
    clearTimeout(manualTimer)
    setLevel('none')
    showToast('演示告警已解除')
  } else {
    manualLevel = level
    clearTimeout(manualTimer)
    manualTimer = setTimeout(() => (manualLevel = 'none'), 8000)
    if (level === 'warn') speak(WARN_TEXTS[0])
    if (level === 'danger') addLog('danger', '告警演示', '危险禁区告警效果演示（手动触发）', takeSnapshot())
    if (level === 'core') addLog('critical', '告警演示', '核心遗存保护区强声光告警效果演示（手动触发）', takeSnapshot())
    setLevel(level)
    showToast(`已触发【${LEVEL_NAME[level]}】分级告警演示`)
  }
}

/* ---------- 每帧评估：三类信号汇总 ---------- */
watch(persons, (list) => {
  if (!cameraOn.value) return
  const video = getVideo()
  if (!video || !video.videoWidth) return
  const vw = video.videoWidth
  const vh = video.videoHeight

  let desired = 'none'

  // 信号1：围栏越界（脚底中心点射线法判定）
  let fenceLevel = 'none'
  for (const d of list) {
    const [bx, by, bw, bh] = d.bbox
    const feet = { x: (bx + bw / 2) / vw, y: (by + bh) / vh }
    const hit = evaluatePoint(feet)
    if (hit && RANK[hit] > RANK[fenceLevel]) fenceLevel = hit
    if (fenceLevel === 'core') break
  }
  desired = maxLevel(desired, handleFenceLevel(fenceLevel))

  // 信号2：研学监管事件（脱队 / 越界 / 人数缺失，composable 内部已做确认与冷却）
  if (studyState.active) {
    const events = studyEvaluate(list, vw, vh, evaluatePoint)
    for (const ev of events) {
      speak(ev.speak)
      addLog(
        ev.level,
        ev.type,
        ev.message,
        takeSnapshot(),
        nightPatrol.value ? { night: true } : {},
      )
      desired = maxLevel(desired, ev.level === 'critical' ? 'core' : 'danger')
    }
  }

  // 信号3：夜间无人值守非法入侵
  desired = maxLevel(desired, checkNightIntruder(list))

  // 手动演示告警在保持期内参与取最高（避免被实时帧冲掉）
  if (manualLevel !== 'none') desired = maxLevel(desired, manualLevel)

  setLevel(desired)
}, { flush: 'post' })

watch(cameraOn, (on) => {
  if (!on) {
    setLevel('none')
    manualLevel = 'none'
    clearTimeout(manualTimer)
  }
})

/* ---------- 模式联动 ---------- */
// 研学开关 ↔ 研学监管状态
watch(studyMode, (on) => {
  studyState.active = on
  if (!on) studyReset() // 关闭研学模式：清空轨迹与累计计数
})
watch(teamTotal, (n) => (studyState.teamTotal = n))

// 系统模式三选一：同步研学开关
watch(activeMode, (m) => {
  if (m === 'study') {
    studyMode.value = true
    showToast('已切换研学模式：队伍防走失防越界监管启动')
  } else {
    if (studyMode.value) studyMode.value = false
    if (m === 'unattended') showToast('已切换无人值守模式：24 小时循环巡查启动')
    if (m === 'normal') showToast('已切换普通监测模式')
  }
})
watch(studyMode, (on) => {
  if (on && activeMode.value !== 'study') activeMode.value = 'study'
  if (!on && activeMode.value === 'study') activeMode.value = 'normal'
})

/* ---------- 24h 时间轴事件 ---------- */
function handlePatrolSetTime(min) {
  setSimMinutes(min)
}
function handlePatrolFast(delta) {
  fastForward(delta)
  showToast(`模拟时间快进至 ${clockText.value}`)
}
function handlePatrolReal() {
  followRealTime()
  showToast('已切回系统真实时间')
}

/* ---------- 悬浮工具条 ---------- */
function handleQuickCamera() {
  if (cameraOn.value) handleCloseCamera()
  else handleOpenCamera()
}

/* ---------- 轻提示 ---------- */
function showToast(msg) {
  toast.value = msg
  clearTimeout(toastTimer)
  toastTimer = setTimeout(() => (toast.value = ''), 2600)
}
</script>

<template>
  <div class="h-screen flex flex-col overflow-hidden bg-gray-100">
    <!-- 三级严重告警：全屏红光呼吸覆盖层 -->
    <div
      v-if="alarmLevel === 'core'"
      class="fixed inset-0 z-40 pointer-events-none animate-screen-flash"
    ></div>

    <NavHeader :status="systemStatus" />

    <main class="flex-1 flex min-h-0 gap-4 p-4">
      <section class="w-[70%] min-w-0">
        <VideoCanvas
          ref="vcRef"
          :camera-on="cameraOn"
          :fences="fences"
          :drawing="drawing"
          :detections="detections"
          :interference-filter="interferenceFilter"
          :alarm-level="alarmLevel"
          :error-msg="combinedError"
          :study-active="studyMode"
          :study-info="studyInfo"
          :night-mode="nightPatrol"
          :clock-text="clockText"
          @point-add="handlePointAdd"
          @draw-complete="handleDrawComplete"
          @draw-cancel="handleCancelDraw"
          @cursor-move="moveCursor"
          @quick-camera="handleQuickCamera"
          @demo-alarm="handleDemoAlarm"
        />
      </section>
      <aside class="w-[30%] min-w-0">
        <ControlPanel
          v-model:active-level="activeLevel"
          v-model:interference-filter="interferenceFilter"
          v-model:study-mode="studyMode"
          v-model:team-total="teamTotal"
          v-model:active-mode="activeMode"
          :camera-on="cameraOn"
          :model-loading="modelLoading"
          :model-ready="modelReady"
          :person-count="persons.length"
          :alarm-level="alarmLevel"
          :fence-counts="fenceCounts"
          :drawing-active="drawing.active"
          :study="studyState"
          :patrol="{
            simMinutes, useRealTime, isNight, periodLabel, clockText,
            cursorPercent, dayRange,
          }"
          @open-camera="handleOpenCamera"
          @close-camera="handleCloseCamera"
          @start-draw="handleStartDraw"
          @save-fences="handleSaveFences"
          @clear-fences="handleClearFences"
          @cancel-draw="handleCancelDraw"
          @patrol-set-time="handlePatrolSetTime"
          @patrol-fast-forward="handlePatrolFast"
          @patrol-follow-real="handlePatrolReal"
        />
      </aside>
    </main>

    <AlarmLogPanel :logs="logs" @clear="clearLogs" @export="exportLogs" />

    <!-- 操作轻提示 -->
    <Transition
      enter-active-class="transition duration-200"
      enter-from-class="opacity-0 translate-y-2"
      leave-active-class="transition duration-200"
      leave-to-class="opacity-0 translate-y-2"
    >
      <div
        v-if="toast"
        class="fixed bottom-60 left-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-lg
               bg-gray-900/85 text-white text-xs shadow-lg"
      >
        <i class="fa-solid fa-circle-check text-emerald-400 mr-1.5"></i>{{ toast }}
      </div>
    </Transition>
  </div>
</template>
